<?php
    session_start();
    if (!isset($_SESSION["login"])){
        header("location:formLogin.php");
    }
?>
<?php
include("model.php");
include("haut.php");
?>

    <section>
            <article>
                <h1>Choisi un Filier</h1>
                <div class="article">
                <ol>
                    <?php  foreach($filiers as $f) {?>
                           <li><a href="listeEtudiants.php?codef=<?=$f["codeFiliere"] ?>"><?=$f["intituleFiliere"]?></a></li> <br>
                    <?php } ?>
                </ol>
                </div>
            </article>


    <?php include("bas.php"); ?>

<?php
    $etudians[]=array("A1234","Hassan","Hassani","SMI",18);
    $etudians[]=["B1234","Othmane","Othmani","SMP",10];
    $etudians[]=array("C1234","kaslan","Kaslani","SMC",5);
    $etudians[]=["D1234","khalid","khaldani","SMA",19];
    $etudians[]=array("E1234","NArjiss","Najari","SVI",13);
    $etudians[]=array("F1234","Fouad","Moufid","STU",11);
    $etudians[]=["G2444","kamal","ahmed","SMI",15];
    $etudians[]=["H53455","karmodi","mohamed","SMA",2];
    $etudians[]=["I5423","kharobi","ahmed","SMI",10];
    $etudians[]=["J6456","jalloli","karim","SMP",12];
    $etudians[]=["K5235","karimi","rachid","SMI",8];
    $etudians[]=["L5627","ahmadi","ahmed","SVI",18];
    $etudians[]=["M5527","hamdani","ahmed","SMA",17];
    $etudians[]=["N6411","salmi","hamid","SMA",14];
    $etudians[]=["O5364","rachidi","jamal","SMI",7];
    $etudians[]=["P0003","hassoni","ahmed","SMP",19];
    $etudians[]=["Q9588","hamdaoui","said","SMI",13];
    $etudians[]=["R11111","salmi","hamid","SMA",16];
    $etudians[]=["S8572","halimi","jamal","SMI",11];
    $etudians[]=["T04738","rajaoui","ahmed","SMP",12];
    $etudians[]=["U74748","ouidadi","said","SMI",9];

    $filiers[]=["codeFiliere"=>"SMI","intituleFiliere"=>"Filiere SMI"];
    $filiers[]=["codeFiliere"=>"SMA","intituleFiliere"=>"Filiere SMA"];
    $filiers[]=["codeFiliere"=>"SMP","intituleFiliere"=>"Filiere SMP"];
    $filiers[]=["codeFiliere"=>"SVT","intituleFiliere"=>"Filiere SVT"];

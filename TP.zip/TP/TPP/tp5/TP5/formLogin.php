<?php
include("haut.php");
?>
<section>
        <article>
            <h1>Autentification </h1>
            <div class="article">
            <form name="form_login" action="verifier.php"  method="post">
                <label for="login">Login</label><span>(index "moi")</span>
                <input type="text" id="login" name="login">
                <label for="password">Password</label><span>(index "douz")</span>
                <input type="password" id="password" name="password">
                <input type="submit" value="Envoyer" >
                <input type="button" value="Annuler">
            </form>
            </div>
        </article>
    <?php include("bas.php");?>
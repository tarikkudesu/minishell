<?php
    if (!isset($_GET["Langue"]) || !isset($_GET["colorText"]) || !isset($_GET["colorBG"])) {
    	header("location:formOption.php");
    }
    setcookie("Langue",$_GET["Langue"],time()+60*60*24*10);
    setcookie("colorText",$_GET["colorText"],time()+60*60*24*10);
    setcookie("colorBG",$_GET["colorBG"],time()+60*60*24*10);
    header("location:index.php");
?>
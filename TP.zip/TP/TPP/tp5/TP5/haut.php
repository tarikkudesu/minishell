<?php
 function afficherDate($lang){
    $jours["FR"]=["dimanche","lundi","mardi","mercredi","jeudi","vendredi","samedi"];
    $jours["EN"]=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    $jours["AR"]=["الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];
    $moins["FR"]=["Janvier","Fevrier","Mars","Avril","Mai","Juin","Juillet","Aout","Septembre","Octobre","Novembre","Decembre"];
    $moins["AR"]=["	يناير","فبراير","مارس","أبريل","ماي","يونيو","يوليوز","غشت","سبتمبر","أكتوبر","نوفمبر","ديسمبر"];
    $moins["EN"]=["January","February","March","April","May","June","July","August","September","October","November","December"];
    $d = getdate();
    $wj  = $d["wday"];
    $mj = $d["mday"];
    $m = $d["mon"];
    $d=$jours[$lang][$wj]."   ".$moins[$lang][$m-1]." ".$d["year"];
    return $d;
   }
   $lang= isset($_COOKIE["Langue"])?$_COOKIE["Langue"]:"AR";
   $colorBG=isset($_COOKIE["colorBG"])?$_COOKIE["colorBG"]:"white";
   $colorText=isset($_COOKIE["colorText"])?$_COOKIE["colorText"]:"black";
   $date=afficherDate($lang);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
  <link rel="stylesheet" href="style.css">
  <script src="javaS.js"></script>
</head>
<body style="background-color: <?= $colorBG ?> ; color: <?= $colorText?>">
<header>
  <span class="date" > <?=  $date  ?></span>
    <img src="téléchargement.jfif">
    <h4>Faculté des Sciences Dhar Mehraz, Fès</h4>
    <hr/>
    <div style="text-align: right">
        <?php if(isset($_SESSION["login"])){?>
            <p>welcome <?=$_SESSION["login"]?></p>
            <a href="deconnecter.php">déconnecter</a>
        <?php } else{ ?>
            <a href="formLogin.php">connecter</a>
        <?php } ?>
        || <a href="formOption.php">options</a>
    </div>


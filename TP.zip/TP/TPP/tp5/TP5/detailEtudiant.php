<?php
include("model.php");
include("haut.php");
$codeE = $_GET["codeE"];
$etudiant=getEtudiant($codeE);
?>
<section>
        <article>
            <h1>détail de l'étudiant <?php echo $codeE ?> </h1>
            <div class="article">
            <p> le code est : <?= $etudiant[0] ?> </P>
            <p> le Nom est : <?= $etudiant[1] ?> </P>
            <p> le Prénom est : <?= $etudiant[2] ?> </P>
            <p> la Note est : <?= $etudiant[4] ?> </P>
            <p> la Filiere est : <?= $etudiant[3] ?> </P>
            <a href="">Modifier</a>
            <a href="">Supprimer</a>
            </div>
        </article>






<?php
include("bas.php");
?>
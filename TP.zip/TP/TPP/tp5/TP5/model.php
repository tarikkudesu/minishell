<?php
    include("data.php");
    function getEtudiant($code){
        foreach($GLOBALS["etudians"] as $e){
            if($e[0]==$code){
                return $e;
            }
        }
    }
    function EtudiansParFiliere($filiere){
    $Liste=[];

            foreach($GLOBALS["etudians"] as $e){
                if($e[3]==$filiere)
                    $Liste[]=$e;
            }
            return $Liste;
        }
        /////////////////////
        function  getListeParFiliere($filiere){
        $Liste=[];
            foreach($GLOBALS["etudians"] as $e){
                if($e[3]==$filiere)
                    if($e[4]>=MOY_REUSSITE){
                        $Liste[]=$e;
                    }
            }
            return $Liste;
        }
        ////////////////
        function getMax($tab){
            $max=0;
            foreach($tab as $t){
                if($t[4]>=$max){
                    $max=$t[4];
                }
            }
            return $max;
        }
        /////////////////////////
        function getMention($note){
            if($note<MOY_REUSSITE){
                return "Ajourné!";
            }
            if($note>=MOY_REUSSITE && $note<12){
                return "Passable";
            }
            if($note>=12 && $note<14){
                return "Assez Bien";
            }
            if($note>=14 && $note<16){
                return "Bien";
            }
            if($note>=16 && $note<18){
                return "Tres Bien";
            }
            if($note>=18 && $note<20){
                return "Excellent";
            }
        }
        ////////////////////////////
        function TopNoteParfilière($filiere){
            $ListeFiliere=getListeParFiliere($filiere);
            return getMax($ListeFiliere);
        }
        function abbreviation($filiere){
            switch ($filiere){
                case "Sciences de la Matière Chimie" : return "SMC";
                case "Sciences de la Matière Physique" : return "SMP";
                case "Sciences Mathématiques et Applications": return "SMA";
                case "Sciences Mathématiques et Informatique" : return "SMI";
                case "Sciences de la Terre et de l'Univers" : return "STU";
                case "Sciences de la Vie" : return "SVI";
            }
        }
?>

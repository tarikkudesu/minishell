function verifier(){
    let code = document.getElementById("code");
    let nom = document.getElementById("nom");
    let note = document.getElementById("note");
    let liste =document.getElementById("liste");
    let prenom = document.getElementById("prenom");

    let err_code = document.getElementById("err_code");
    let err_nom = document.getElementById("err_nom");
    let err_prenom = document.getElementById("err_prenom");
    let err_note = document.getElementById("err_note");
    let err_filiere=document.getElementById("err_filiere");
    let onSub= true;
    if (code.value==""){
        err_code.innerHTML=" * champ obligatoire";
        err_code.style.color="red";
        err_code.style.fontSize="13px";
        onSub = false;
    }else err_code.innerHTML="";

    if (nom.value==""){
        err_nom.innerHTML=" * champ obligatoire";
        err_nom.style.color="red";
        err_nom.style.fontSize="13px";
        onSub = false;
    }else err_nom.innerHTML="";
    if (prenom.value==""){
        err_prenom.innerHTML=" * champ obligatoire";
        err_prenom.style.color="red";
        err_prenom.style.fontSize="13px";
        onSub = false;
    }else err_prenom.innerHTML="";

    if (note.value==""){
        err_note.innerHTML=" * champ obligatoire";
        err_note.style.color="red";
        err_note.style.fontSize="13px";
        onSub = false;
    }else {
        if (!(note.value<=20 && note.value>=0)){
            err_note.innerHTML=" * la note doit être entre 0 et 20";
            err_note.style.color="red";
            err_note.style.fontSize="13px";
            onSub = false;
        }else err_note.innerHTML=""
    };

    if (liste.value==""){
        err_filiere.innerHTML=" * champ obligatoire";
        err_filiere.style.color="red";
        err_filiere.style.fontSize="13px";
        onSub = false;
    }else err_filiere.innerHTML="";
    return onSub;
}
function Upper(){
    document.getElementById("code").value=document.getElementById("code").value.toUpperCase();
}



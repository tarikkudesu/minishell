   <?php
       session_start();
       if (!isset($_SESSION["login"])){
           header("location:formLogin.php");
       }
   ?>
    <?php
    include("model.php");
    include("haut.php");
    ?>
<section>
    <article>
        <h1>Ajouter un étudiant</h1>
        <div id="form" class="article">
            <form name="form" action="resultat.php" onsubmit=" return verifier()" method="post">
                <label for="code">Entrez le code:</label><span id="err_code"></span>
                <input type="text" id="code" onkeyup="Upper()" name="code">
                <label for="nom">Entrez le nom:</label><span id="err_nom"></span>
                <input type="text" id="nom" name="nom">
                <label for="prenom">Entrez le prenom:</label><span id="err_prenom"></span>
                <input type="text" id="prenom" name="prenom">
                <label for="note">Entrez la Note:</label><span id="err_note"></span>
                <input type="text" id="note" name="note">
                <label for="liste">Filière:</label><span id="err_filiere"></span>
                <input list="filiere" name="filiere" id="liste" >
                <datalist id="filiere" name="filiere">
                    <option value="Sciences de la Matière Chimie"></option>
                    <option value="Sciences de la Matière Physique"></option>
                    <option value="Sciences Mathématiques et Applications"></option>
                    <option value="Sciences Mathématiques et Informatique"></option>
                    <option value="Sciences de la Terre et de l'Univers"></option>
                    <option value="Sciences de la Vie"></option>
                </datalist>
                <input type="submit" value="Envoyer" >
                <input type="button" value="Annuler">
            </form>
        </div>
    </article>
    <?php include("bas.php");?>


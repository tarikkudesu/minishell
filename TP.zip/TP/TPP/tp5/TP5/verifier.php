<?php
if (!isset($_POST["login"]) || !isset($_POST["password"]) || $_POST["login"]!= "moi" || $_POST["password"]!= "douz") {
	include ("formLogin.php");
	exit();
}
session_start();
$_SESSION["login"]=$_POST["login"];
header("location:listeFilieres.php");
 ?>
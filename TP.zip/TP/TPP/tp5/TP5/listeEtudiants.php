<?php
    include("model.php");
    define("MOY_REUSSITE",10);
    $filiere=$_GET["codef"];
    $ListeSMI=EtudiansParFiliere($filiere);
    $nbrReussis=count(getListeParFiliere($filiere));
    $topF=TopNoteParfilière($filiere);
?>



    <?php include("haut.php")?>

<section>
    <article>
        <h1>Liste des étudiants de la filière: <?=$filiere?></h1>
        <div class="article">
            <p>Nombre des étudiants réussis:<?=$nbrReussis?></p>
            <p>Meilleure note:<?=$topF?></p>
        </div>
        <div class="article">
            <table>
                <tr>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Note</th>
                    <th>Mention</th>
                </tr>
                <?php
                    foreach($ListeSMI as $t){?>
                        <tr>
                        <td> <a href="detailEtudiant.php?codeE=<?= $t[0] ?>"><?=  $t[2] ?></a></td>
                       <td> <a href="detailEtudiant.php?codeE=<?=$t[0]?>"><?=  $t[1] ?>  </a></td>
                       <td> <a href="detailEtudiant.php?codeE=<?=$t[0]?>"><?=  $t[4] ?></a></td>
                       <td> <a href="detailEtudiant.php?codeE=<?=$t[0]?>"><?=  getMention($t[4]) ?></a></td>
                       </tr>
                    <?php } ?>
            </table>
        </div>
    </article>
<?php include("bas.php");?>

<?php include("haut.php")?>
    <section>
        <article>
            <h1>Gestion des étudiants</h1>
            <div class="article">
                <p>Bienvenue dans la page d'acceuil de notre application Web. Vous pouvez gérer d'une manière très aisée la base de données des étudiants.En accèdant à la liste, vous pouvez voir le détail d'un étudiant et le modifier ou le supprimer. A partir du menu, vous pouvez ajouter un nouveau étudiants ou afficher toute la liste. Testez!!</p>
            </div>
        </article>
    <?php include("bas.php");?>
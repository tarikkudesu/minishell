        <nav>
            <ul>
                <li><a href="index.php">Acceuil</a></li>
                <li><a href="listeFilieres.php">Liste des filiers</a></li>
                <li><a href="form.php">Ajouter un étudiant</a></li>
            </ul>
        </nav>
    </section>
<footer>
<?php
echo '<p class="copyright"><span>&#169;</span>copyright:SMI6 2023<br/>Faculté des Sciences Dhar Mehraz<br/>smi6@fsdmfes.ac.ma</p>';
?>
</footer>
</body>
</html>
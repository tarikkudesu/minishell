<?php
    include("haut.php");
    include("model.php");
    $code_a=$_POST["code"];
    $nom_a=$_POST["nom"];
    $prenom_a=$_POST["prenom"];
    $note_a=$_POST["note"];
    $filiere_a=$_POST["filiere"];
    $abbr=abbreviation($filiere_a);
    $s="\$etudians[]=['$code_a','$nom_a','$prenom_a','$abbr',$note_a];";
   $id=fopen("data.php","a");
   if($id){
    fputs($id,$s);
    fclose($id);
   }
?>

    <section>
            <article>
                <h1>Réception des informations </h1>
                <div class="article">
                <p> le code est : <?= $code_a ?> </P>
                <p> le Nom est : <?= $nom_a ?> </P>
                <p> le Prenom est : <?= $prenom_a ?> </P>
                <p> la note est : <?= $note_a ?> </P>
                <p> la filiere est : <?= $filiere_a ?> </P>
                </div>
            </article>
            <article>
                <h1>Informations environnement</h1>
                <br /><b>Votre adresse ($_SERVER["REMOTE_ADDR"]):</b>  <?= $_SERVER["REMOTE_ADDR"] ?>
                <br /><b>Votre Navigateur ($_SERVER["HTTP_USER_AGENT"]):</b> <?= $_SERVER["HTTP_USER_AGENT"] ?>
                <br /><b>Vous étiez sur la page($_SERVER["HTTP_REFERER"]): </b> <?= $_SERVER["HTTP_REFERER"] ?>
                <br /><b>Vous êtes actuellement dans le script ($_SERVER["PHP_SELF"]): </b> <?= $_SERVER["PHP_SELF"] ?>
                <br /><b>Vous êtes actuellement dans le script(__FILE__): </b> <?= __FILE__ ?>
                <br /><b>à la ligne (__LINE__):  <?= __LINE__ ?>
                <br /><b>Répertoire (__DIR__):  <?= __DIR__ ?>
                <br /><b>La version de PHP tournée par le serveur (PHP_VERSION):  </b> <?= PHP_VERSION ?>
                <br /><b>Le système d'exploitation du seveur (PHP_OS):  </b> <?= PHP_OS ?>
            </article>
            <article>
                <nav>
                    <ul>
                        <li><a href ="form.php">Revenir au formulaire d'ajout</a></li>
                        <li><a href ="javascript:history.go(-1)">Revenir à la précédente</a></li>
                    </ul>
                </nav>
            </article>
<?php
include("bas.php");
?>



<?php include("haut.php"); ?>
 <section>
        <article>
            <h1>Précisez Vos préférences</h1>
            <div class="article">
            <form  method="get" action="apply.php">
            <table>
            <tr>
                <td>Langue de la date</td>
                <td>
                    <select id="Langue" name = "Langue" >
                        <option value="AR" >العربية</option>
                        <option value="FR" >Francais</option>
                        <option value="EN" >English</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td >Couleur de text</td>
                <td>
                    <input type="radio" name="colorText" value="red">
                    <label for="colorText"><b style="color: red;">Rouge</b></label><br>

                    <input type="radio" name="colorText" value="green">
                    <label for="colorText"><b style="color: green;">Vert</b></label><br>

                    <input type="radio" name="colorText" value="yellow">
                    <label for="colorText"><b style="color: yellow;">Jeun</b></label><br>

                    <input type="radio" name="colorText" value="blue">
                    <label for="colorText"><b style="color: blue;">Bleu</b></label><br>

                    <input type="radio" name="colorText" value="black" checked>
                    <label for="colorText"><b style="color: black;">Noir</b></label><br>
                </td>
            </tr>

            <tr>

                <td>Coleur de l'arrière plan</td>
                <td>
                    <input type="radio" name="colorBG" value="red">
                    <label for="colorBG"><b style="background-color: red;">Rouge</b></label><br>

                    <input type="radio" name="colorBG" value="green">
                    <label for="colorBG"><b style="background-color: green;">Vert</b></label><br>

                    <input type="radio" name="colorBG" value="yellow">
                    <label for="colorBG"><b style="background-color: yellow;">Jeun</b></label><br>

                    <input type="radio" name="colorBG" value="blue">
                    <label for="colorBG"><b style="background-color: blue;">Bleu</b></label><br>

                    <input type="radio" name="colorBG" value="white" checked>
                    <label for="colorBG"><b style="background-color: white;">Blanc</b></label><br>
                </td>
            </tr>

            <tr>
                <td id="buttons" colspan="2">
                    <input type="submit" value="Envoyer">
                </td>
            </tr>
            <tr>
                <td id="buttons" colspan="2">
                    <input type="button" value="Anuller">
                </td>
            </tr>
        </table>
    </form>            </div>
        </article>
    <?php include("bas.php");?>
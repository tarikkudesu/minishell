<?php
   function getCn(){
    static $cn;
    if(!$cn){
        $db = 'mysql:host=localhost;dbname=smi2023';
        $user = 'root';
        $password = '';
        $cn = new PDO($db, $user, $password);
    }
    return $cn;
   }

   function findAll($table){
    return getCn()->query("select * from $table")->fetchAll();
}

function find($table, $criteria){
    return getCn()->query("select * from $table where $criteria")->fetchAll();
}

function addStudent(array $e){
    //$resultat = getCn()->prepare("insert into Etudiant (codeE, NOM, Prenom, filiere, Note) values (?,?,?,?,?)");
    //$resultat->execute($e);
    $t =[
        $e["CodeE"],
        $e["Nom"],
        $e["Prenom"],
        $e["Filiere"],
        $e["Note"],
    ];
    getCn()->prepare("insert into Etudiant (codeE, NOM, Prenom, filiere, Note) values (?,?,?,?,?)")->execute($t);
}

function delete ($table, $id){
    getCn()->prepare("delete from $table where id = ?")->execute([$id]);
}

unction updateStudent(array $e){
    //$resultat = getCn()->prepare("insert into Etudiant (codeE, NOM, Prenom, filiere, Note) values (?,?,?,?,?)");
    //$resultat->execute($e);
    $t =[
        $e["CodeE"],
        $e["Nom"],
        $e["Prenom"],
        $e["Filiere"],
        $e["Note"],
        $e["id"]
    ];
    getCn()->prepare("update Etudiant (codeE, NOM, Prenom, filiere, Note) values (?,?,?,?,?)")->execute($t);
}
   ?>

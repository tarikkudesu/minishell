<?php
    function findOne($table, $id){
        $rq = getCn()->prepare("select *from $table where id = ?");
        $rq->execute([$id]);
        return $rq->fetch();
    }

    

    

    function getNoteMax($f){
        return getCn()->query("select max(Note) from Etudiant where filiere = $f");
    }

    

    


?>
Student Management System
-------------------------------------------------------
this is a student management system by using HTML+CSS FOR Front-end and 
PHP for Back-end and SQL FOR database.

........................................................
"sms.sql" is DATABASE file used.
--------------------------------------------------------
"index.html" is html main file.
"style.css" is css file used for all pages.
"adminlogin.html" is login HTML page for admin.
"studentlogin.html" is login HTML page for student.
"admin.html" is user HTML page for ADMIN.
"Student.html" is user HTML page for STUDENT.
--------------------------------------------------------
"connect.php" is php backend for "student.html".
"studentloginconnect.php" is php backend for "studentlogin.html".
"adminloginconnect.php" is php backend for "adminlogin.html".
"adminconnect.php" is php backend for "admin.html".
----------------------------------------------------------

all output images are stored in "output Screenshots" folder.

........................................................

Project By: SAKSHI RAVINDRA SALUNKHE.

<?php
//include('Controllers/EtudiantController.php');
// Définir la constante MOY_REUSSITE
define("MOY_REUSSITE", 10);
function getMention($note) {
	if ($note >= 16) {  
		return "Très bien";
	} 
 
	elseif ($note >= 14) {
		return "Bien";
	}  
	elseif ($note >= 12) {
		return "Assez bien";
	} 
	elseif ($note >= 10) {
		return "Passable";
  }else {
		return "Ajourné";
		}
}
// Fonction pour récupérer une liste d'étudiants réussis pour une filière donnée
function getCn()
{ 
	static $cn;
	if(empty($cn)){
	$user = 'root';
	$password = '';
	$db = 'mysql:host=localhost;dbname=SMIS6';
	$cn =new PDO($db, $user, $password);
	}
	return $cn;
}
function getTable($table)
{
	return getCn()->query("select * from $table ")->fetchAll();
}

function getListeParFiliere($filiere) {
    return getCn()->query("select * from etudiant where Filiere = $filiere")->fetchAll();
}

function getMeilleureNote() {
  return getCn()->query("select max(Note) from etudiant ")->fetchColumn();
}

function getMeilleureNoteParFiliere($filiere){
	return getCn()->query("select max(Note) from etudiant where Filiere=$filiere")->fetchColumn();
  
}
function findOne($table,$id) {
	return getCn()->query("SELECT * FROM $table WHERE id = $id")->fetch();
	
}
function AjouterEtudiant($e)
{
	$rq="INSERT INTO Etudiant VALUES (NULL,'$e[0]','$e[1]','$e[2]',$e[3],$e[4])";
	getCn()->exec($rq);		
}
function SupprimerEtudiant($id) {
 
  getCn()->exec("DELETE FROM etudiant WHERE id= $id");
}
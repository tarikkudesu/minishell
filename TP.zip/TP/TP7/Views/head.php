<?php
function afficherDate($lang)
{
	$moisAr = array(
    1 => 'يناير',
    2 => 'فبراير',
    3 => 'مارس',
    4 => 'أبريل',
    5 => 'مايو',
    6 => 'يونيو',
    7 => 'يوليو',
    8 => 'أغسطس',
    9 => 'سبتمبر',
    10 => 'أكتوبر',
    11 => 'نوفمبر',
    12 => 'ديسمبر'
	);

	$joursAr = array(
    1 => "الاثنين",
    2 => "الثلاثاء",
    3 => "الأربعاء",
    4 => "الخميس",
    5 => "الجمعة",
    6 => "السبت",
    7 => "الأحد"
	);

	$mois = array(
    1 => 'Janvier',
    2 => 'Février',
    3 => 'Mars',
    4 => 'Avril',
    5 => 'Mai',
    6 => 'Juin',
    7 => 'Juillet',
    8 => 'Août',
    9 => 'Septembre',
    10 => 'Octobre',
    11 => 'Novembre',
    12 => 'Décembre'
	);
	$jours = array(
    1 => "Lundi",
    2 => "Mardi",
    3 => "Mercredi",
    4 => "Jeudi",
    5 => "Vendredi",
    6 => "Samedi",
    7 => "Dimanche"
	);
	$monthsEn = array(
    1 => "January",
    2 => "February",
    3 => "March",
    4 => "April",
    5 => "May",
    6 => "June",
    7 => "July",
    8 => "August",
    9 => "September",
    10 => "October",
    11 => "November",
    12 => "December"
	);
	$days = [
    
    1 => "Monday",
    2 => "Tuesday",
    3 => "Wednesday",
    4 => "Thursday",
    5 => "Friday",
    6 => "Saturday",
	7 => "Sunday"
	];


    switch ($lang)
	{
        case "FR":  $d= $jours[date('w')]." ".date("d")." ".$mois[date("n")]." ".date("Y") ;
		            return $d;
	    case "AN":  $d= $days[date("w")]." ".date("d")." ".$monthsEn[date("n")]." ".date("Y") ;
		            return $d;
		case "AR":  $d= $joursAr[date('w')]." ".date("d")." ".$moisAr[date("n")]." ".date("Y") ;
		            return $d;
		default :   $d= $joursAr[date('w')]." ".date("d")." ".$moisAr[date("n")]." ".date("Y") ;
		            return $d;
	}
}

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<link rel="stylesheet" type="text/css" href="public/style.css" />
</head>
<body >
<div class="top">
<img src= 'public/images/fsdm.jpg' border = '0' hspace = '20' vspace = '20' align = 'left' />
<span class="top">SMI6</span><br />
Facult&eacute; des Sciences Dhar El Mahraz, F&egrave;s </div>
<h4>&nbsp;<span> <?PHP if(isset($_COOKIE["langue"])) echo afficherDate($_COOKIE["langue"]) ; else  echo afficherDate("");?></span></h4>
<p align="right">
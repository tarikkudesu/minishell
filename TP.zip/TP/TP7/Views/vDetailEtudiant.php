

<h1>Détail  d'étudiant : <?=$Etudiant[0]?> </h1>
<hr/>
<ul>
<b> Code : <?=$Etudiant[1]?> </b><br/><br/>
<b> Nom : <?=$Etudiant[2]?> </b><br/><br/>
<b> Prénom : <?= $Etudiant[3]?> </b><br/><br/>
<b> Filiere : <?=$Etudiant[4]?> </b><br/><br/>
<b> Note : <?= $Etudiant[5]?> </b><br/><br/>
</ul>
<a href="index.php?action=Supprimer&id=<?=$Etudiant[0]?>">Supprimer</a>
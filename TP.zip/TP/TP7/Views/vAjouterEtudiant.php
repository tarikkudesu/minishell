<h1 >Ajouter un étudiant</h1>
<hr />

<!-- l'attribut name permet d'accèder facilement au formulaire -->

<form id = "myForm" name = "myForm" action = "Controllers/Ajouter.php" method = "post"  >

<pre>
<!-- chaque  élément de formulaire à un attribut name -->
Entrez le code:              
<input type="text" name="Code" value=""/> <span class="Err" id="ErrCode"> </span>

Entrez le nom:
<input  type="text"  name="Nom" value="" /> <span class="Err" id="ErrNom"> </span>

Entrez le prénom:
<input type="text" name="Prenom" value="" /> <span class="Err" id="ErrPrenom"> </span>

Entrez la Note :
<input type="text" name ="Note" value="" /> <span class="Err" id="ErrNote"> </span>
Filière:
<select name = "Filiere">
		<option  value =  "1"	>Sciences Mathématiques et Informatique</option>
		<option  value =  "2"	>Sciences Mathématiques et Application</option>
		<option  value =  "3"	>Sciences de la Matière Physique</option>
		</select> <span class="Err"> </span>

<input  type = 'submit'  value =  'Envoyer' /> <input  type = 'reset'  value =  'Annuler' />
</pre>
</form>



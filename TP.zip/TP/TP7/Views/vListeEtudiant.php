
<h1>Liste des étudiants réussis de la filière: SMI</h1>
<hr />
<b>Nombre des étudiants : <?PHP echo count($Etudiant) ?></b><br />
<b>Meilleure note : <?=$Note?> </b> <br />
<hr />
<table border="1" align = "center" width = "60%">		
			<tr> 
				<th>Nom </th>
				<th>Prénom </th>
				<th>Note</th>
				<th>Mention</th>
			</tr>	
		 
		 <?PHP foreach($Etudiant as $e ) {?>
			<tr>
				<td><a href="index.php?action=DetailE&id=<?=$e["id"]?>"> <?PHP echo $e[2] ?></a> </td>
				<td><a href="index.php?action=DetailE&id=<?=$e["id"]?>"> <?PHP echo $e[3] ?> </a> </td>
				<td><a href="index.php?action=DetailE&id=<?=$e["id"]?>"> <?PHP echo $e[5] ?> </a> </td>
				<td><a href="index.php?action=DetailE&id=<?=$e["id"]?>"> <?PHP echo getMention($e[5])  ?> </a></td>
			</tr>
			
			
		 <?PHP }?>
          <tr>
		  <td colspan="4" style="text-align: center"><a  href="index.php?action=AjouterE" >Ajouter</a></td>
		  </tr>
</table>


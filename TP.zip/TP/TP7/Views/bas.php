<?php
?>
<br />
<hr />
<a href ="index.php?action=index">Acceuil</a> |
<a href ="index.php?action=ListeE">Liste de étudiants</a> |
<a href ="index.php?action=AjouterE">Ajouter un étudiant</a> |
<a href ="index.php?action=ListeF">Liste des filier</a>
<br /><hr /><br />
<div class="bas">&copy; copyright: SMI6 2023<br />Facult&eacute; des Sciences Dhar El Mahraz</br>smi6@fsdm.usmba.ac.ma</div>
</body>
</html>

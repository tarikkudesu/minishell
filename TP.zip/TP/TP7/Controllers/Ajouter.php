<?php
include("../models/EtudiantManager.php"); 
AjouterEtudiant(array($_POST["Code"],$_POST["Nom"],$_POST["Prenom"],$_POST["Filiere"],$_POST["Note"]));
header("location: ../index.php");
?>
<?php
 include("models/EtudiantManager.php");
 
 function ListeFAction()
 {
	render("Views/vListeFiliere.php",["filiere"=>getTable("filiere")]);
 }
 function ListeEAction()
 {
	$id = $_GET["id"] ?? "";
	render("Views/vListeEtudiant.php",["Etudiant"=>getTable("etudiant"),'Note'=>getMeilleureNote($id)]);
 }
 function indexAction()
 {
 render("Views/index.php");
 
 }
 function AjouterEAction()
 {
 render("Views/vAjouterEtudiant.php");
 }
 function DetailEAction()
 {
	$id = $_GET["id"] ?? ""; 
	if (empty($id)) throw new Exception ("Vous n'avez pas fourni l'id de l'étudiant voulu!!") ;
	if (!is_numeric($id)) throw new Exception ("l'id fourni est non valide!!") ;
	render("Views/vDetailEtudiant.php",['Etudiant'=>findOne("Etudiant",$id),'Filiere'=>getTable('Filiere')]);
 }
 function ListeEFAction()
 {
	render("Views/vListeEtudiant.php",['Etudiant'=>getListeParFiliere($id),'Note'=>getMeilleureNoteParFiliere($id)]);
 }
 function SupprimerAction() {
	$id = $_GET["id"] ?? "";
	SupprimerEtudiant($id);
	ListeEAction($id);
}
 
 function render($view,array $variables=[])
 {
	extract($variables);
	require("Views/head.php");
	require($view);
	require("Views/bas.php");
	
 }
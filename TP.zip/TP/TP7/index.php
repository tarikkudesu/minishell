<?php
include("Controllers/EtudiantController.php");

$id= $_GET["id"] ?? NULL ;
//DetailEAction($id);
$action = $_GET["action"] ?? "index";
$action=$action."Action";
if(!is_callable($action))die ("Action n'authorise pas");
$action($id);
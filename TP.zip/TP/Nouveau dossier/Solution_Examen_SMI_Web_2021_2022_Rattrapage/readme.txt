Corrigez l'énnoncé:

- Dans le fichier index.php: ajouter au début
  require_once("library.php");


- Dans le controlleur, ligne 31: remplacez 1 par 2 (c'est à dire: dans l'action index 
	/**
		Cette action permet de gérer le formulaire
		de la figure 2
	*/
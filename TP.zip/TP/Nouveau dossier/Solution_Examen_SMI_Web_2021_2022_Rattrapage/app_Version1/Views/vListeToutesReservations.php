<h1>Liste des réservations active te non active</h1>

<hr />
<div align="right"><b><a href ="index.php">Réserver une salle</a> </b></div><br><br>
<table border="2" align = "center" width = "80%">
			<tr> 
				<th>id</th>
				<th>Email Createur </th>
				<th>Salle</th>
				<th>Date</th>
				<th>Créneau</th>
				<th>Action</th>
				<th>etat</th>
			</tr>	
		 
	<?php foreach ($Reservations as $R) { ?>	 
			<tr>
				<td> <?= $R["id"] ?></td>
				<td> <?= $R["email"] ?> </td>
				<td> <?= $salles[$R["idSalle"]-1]["intitule"] ?>  </td>
				<td> <?= $R["date"] ?> </td>
				<td> <?= $R["creneau"] ?> </td>
				<td> <a href = "index.php?action=demandeSuppression&id=<?= $R["id"] ?>">Supprimer</a><b> || </b> <a href = "index.php?action=demandeModiffier&id=<?= $R["id"] ?>">Modiffier</a> </td>
				<td><a href = "index.php?action=etatReservation&id=<?= $R["id"] ?>"><?=$R["etat"]?> </a></td>
			</tr>
	<?php }?>
</table>
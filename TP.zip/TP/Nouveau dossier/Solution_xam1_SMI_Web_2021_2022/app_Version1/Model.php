﻿<?php 

function getCn(){	
	static $cn;
	if(!$cn) $cn= new PDO("mysql:host=localhost;dbname=ExamenSMI2022", "root", "");
	return $cn;
}


//cherche la liste de toutes les salles
function getAllSalles(){
	return getCn()->query("select* from Salles")->fetchAll();
}

//teste si la salle est déjà réservée à une date donnée et un créneau donné
function isPossible($reservation) {
	$Rq= getCn()->prepare("select count(*) from reservations where idSalle = ? and date = ? and creneau = ? and etat = 'Active'");
	$Rq->execute($reservation);
	return !($Rq->fetchColumn());
	
}

//cherche la liste de toutes les réservations actives qui ne sont pas encore obsolède (date encore valide, n'est pas dépassée)
function getAllActiveReservations(){
	return getCn()->query("select* from Reservations where etat ='Active' and date >= '" . Date("Y-m-d H:i:s") . "'" )->fetchAll();
}


function getDetailReservation($id){
	$Rq= getCn()->prepare("select * from Reservations where id = ? ");
	$Rq->execute([$id]);
	return $Rq->fetch();
}


function AjouterReservation($R){
	$Reservation=[$R["email"],$R["motif"],$R["idSalle"],$R["date"],$R["creneau"],"Inactif"];
	$Rq= getCn()->prepare("insert into Reservations (email,motif,idSalle,date,creneau,etat) values(?,?,?,?,?,?)");
	$Rq->execute($Reservation);
	return getCn()->lastInsertID() ; //pour retourner l'id automatique de la resérvation nouvellement insérée
}

function activateReservation($token){
	$Rq= getCn()->prepare("update Reservations set etat = 'Active' where id = (select idReservation from tokens where token = ? and Expire >= '" . Date("Y-m-d H:i:s") ."')");
	$Rq->execute([$token]);
}

function deleteReservation($token){
	$Rq= getCn()->prepare("delete from Reservations where id = (select idReservation from tokens where token = ? and Expire >= '" . Date("Y-m-d H:i:s") ."')");
	$Rq->execute([$token]);
}

function ajouterToken(array $t) {	
	$Rq= getCn()->prepare("insert into tokens (idReservation,token, expire) values(?,?,?)");
	$Rq->execute($t);	
}
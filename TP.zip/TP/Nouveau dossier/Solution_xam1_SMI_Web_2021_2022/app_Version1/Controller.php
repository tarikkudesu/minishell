<?php
require_once("Model.php");

function listeReservations(){		
	afficher("vListeReservations.php", ["Reservations"=>getAllActiveReservations()]);	
}


function index(){
	$Reservation = ["email"=>"","motif"=>"","idSalle"=>"","date"=>"","creneau"=>""];
if ($_SERVER["REQUEST_METHOD"]=="POST") {
	
	$Reservation = $_POST;

	//valider les champs du formulaire		
	if(empty($Reservation["email"]))    $erreur["email"] ="L'e-mail ne peut être vide !..."   ;
	elseif(substr(strtolower($Reservation["email"]),-12,12)!="@usmba.ac.ma")    $erreur["email"] ="Utilisez votre mail académique!!..."   ;
	if(empty($Reservation["motif"]))    $erreur["motif"] ="Entrez le motif de la réservation !..."   ;
	if(empty($Reservation["date"]) or $Reservation["date"] < Date("Y-m-d H:i:s"))  $erreur["date"] ="Date de réservation invalide !..."   ;
	elseif(empty($Reservation["creneau"]))    $erreur["creneau"] ="Choisissez un creneau !..."   ;
	elseif(empty($Reservation["idSalle"]))  $erreur["salle"] ="Choisissez une salle !..."   ;
	else {
		$s = $Reservation["idSalle"];
		$d = $Reservation["date"];
		$c = $Reservation["creneau"];			
		if(!isPossible([$s,$d,$c]))  $erreur["salle"] ="Cette Salle est déjà réservée pour la date et le créneau choisi !..."   ;
	}
					
	if (!isset($erreur)) {
		
		//insérer la réservation dans la BD et récupérer son ID automatique
		//puis générer un token et envoyer le au createur pour pouvoir activer la réservation
		$idResrvation = ajouterReservation ($Reservation);						
		generateToken($idResrvation,$Reservation["email"],"activerReservation");		
		header ("location: index.php?action=listeReservations");
	}
}

/*si on arrive ici, ça veut dire que la méthode n'est pas "post", donc c'est le premier affichage du formulaire, oubien, les données envoyées par post ne sont pas valide (donc le tableau $erreur est rempli (isset($erreur)==true)*/
//dans ce cas, on affiche, ou réaffiche le formulaire

$data =[ "salles" => getAllSalles(),
		 "erreur" => $erreur ?? [] ,
		 "reservation" => $Reservation
		];
afficher("vformReservation.php",$data);
}

function demandeSuppression() {
	
	$id =$_GET["id"] ?? "";
	if(empty($id)) throw new Exception ("Il faut fournir l'id de la reservation à supprimer");			
	$Reservation = getDetailReservation($id);			
	generateToken($Reservation["id"],$Reservation["email"],"supprimerReservation");
	header("location:index.php?action=listeReservations");
}

function supprimerReservation() {	
	$token = $_GET["token"] ?? "";	
	if(empty($token)) throw new Exception ("Fournissez un token valide!!..");	
	deleteReservation ($token); //dans le modèle
	header("location:index.php?action=listeReservations");
}

function activerReservation() {	
	$token = $_GET["token"] ?? "";	
	if(empty($token)) throw new Exception ("Fournissez un token valide!!..");	
	activateReservation ($token); //dans le modèle
	header("location:index.php?action=listeReservations");
}

function GenerateToken ($idReservation,$emailCreator,$action) {		
	date_default_timezone_set('Africa/Casablanca');
	$timeExpiration =  date("Y-m-d H:i:s", strtotime('+4 hours')) ; // Expire dans  4h à partir de maintenant
	$token = sha1 ($idReservation . $emailCreator . $timeExpiration . rand(0,999999999)) ; //une chaine aléatoire
	//insérer le token dans la BD
	ajouterToken([$idReservation,$token,$timeExpiration]); 
	
	//Envoyer un email
	//$lien = "http://www.fsdm.usmba.ac.ma/ReservationSalles/index.php?action=$action&token=$token";
	$lien = "index.php?action=$action&token=$token";
	$to= $emailCreator;
	$subject = "Lien pour activer ou supprimer votre réservation" ;
	$message =" Veuillez cliquer sur le lien suivant pour gérer votre réservation. Notez bien que ce lien va expirer le <b> : $timeExpiration </b>. <br> <a href ='$lien'>$lien</a>";  
	
	//mail($to,$subject,$message);
	
	//affichage alternatif; juste pour tester sans utiliser l'email
	require ("Views/vEmailTest.php"); exit;
		
		
}

function afficher ($view, array $data =array()) {
	
	if (file_exists("Views/".$view)) {				
			extract($data);
			ob_start();
			require ("Views/".$view);
			$view = ob_get_clean();			
			
			ob_start();
			require ("Views/templates/template.php");
			$output = ob_get_clean();			
			echo $output;
	}
	else 
			throw new Exception("Fichier Views/$view introuvable");
}
	
	

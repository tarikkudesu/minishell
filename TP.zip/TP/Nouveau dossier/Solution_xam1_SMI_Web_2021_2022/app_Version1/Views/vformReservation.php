<h1>Réserver une salle </h1>

<b>
<form name = "myForm" action = "" method = "post">
<input type="hidden" name="id" value="<?= $reservation["id"] ?>"/>
<pre>
<!-- chaque  élément de formulaire à un attribut name -->
Entrez votre email:              
<input type="text" name="email" value="<?= $reservation["email"] ?>" /> <span class="Err"><?= $erreur["email"] ?? ""?></span>

Entrez le motif de la réservation:
<input  type="text"  name="motif" value="<?= $reservation["motif"] ?>" /> <span class="Err"><?= $erreur["motif"] ?? "" ?></span>

Sélectionnez la salle voulue: <span class="Err"><?= $erreur["salle"] ?? "" ?></span>
<select name = "idSalle">
		<option value="" length = "50">------------------------</option>

		<?php foreach ($salles as $salle) { ?>
			
		<option value="<?= $salle["id"] ?>" <?= ($salle["id"]==$reservation["idSalle"])?"selected": "" ?>><?= $salle["intitule"] ?></option>	
			
		
		<?php } ?>

		
</select>

Entrez la date prévue (format: yyyy-mm--jj): <span class="Err"><?= $erreur["date"]  ?? "" ?></span>
<input type="text" name="date" value="<?= $reservation["date"] ?>" /> 

Sélectionnez un créneau: <span class="Err"><?= $erreur["creneau"]  ?? ""  ?></span>
<input  type="radio" name ="creneau" value="Matin" /> Matin
<input  type="radio" name ="creneau" value="Soir" /> Soir

<input  type = 'submit'  value =  'Envoyer' /> <input  type = 'reset'  value =  'Annuler' />
</pre>


</form>
<div align = "right"><a href ="index.php?action=listeReservations">Voir la liste des réservations</a></div>
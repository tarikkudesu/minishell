-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  lun. 27 juin 2022 à 23:06
-- Version du serveur :  5.7.17
-- Version de PHP :  7.1.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `examensmi2022`
--

-- --------------------------------------------------------

--
-- Structure de la table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `motif` varchar(100) NOT NULL,
  `idSalle` int(10) NOT NULL,
  `date` varchar(100) NOT NULL,
  `creneau` varchar(10) NOT NULL,
  `etat` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `reservations`
--

INSERT INTO `reservations` (`id`, `email`, `motif`, `idSalle`, `date`, `creneau`, `etat`) VALUES
(2, 'me@usmba.ac.ma', 'Test 2', 3, '2022-06-28', 'Soir', 'Inactive'),
(3, 'me@usmba.ac.ma', 'Test 2', 3, '2022-06-28', 'Soir', 'Inactive'),
(4, 'me@usmba.ac.ma', 'Test 2', 3, '2022-06-28', 'Soir', 'Inactive'),
(5, 'me@usmba.ac.ma', 'Test 2', 3, '2022-06-28', 'Soir', 'Inactive'),
(7, 'me@usmba.ac.ma', 'test3', 4, '2022-06-28', 'Matin', 'Active'),
(9, 'me@usmba.ac.ma', 'a', 3, '2022-06-28', 'Matin', 'Active'),
(11, 'A', 'a', 4, '2022-06-27', 'Matin', 'Active'),
(12, 'me@usmba.ac.ma', 'testing 5', 3, '2022-06-29', 'Matin', 'Inactive'),
(13, 'me@usmba.ac.ma', 'testing 5', 3, '2022-06-29', 'Matin', 'Active');

-- --------------------------------------------------------

--
-- Structure de la table `salles`
--

CREATE TABLE `salles` (
  `id` int(11) NOT NULL,
  `intitule` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `salles`
--

INSERT INTO `salles` (`id`, `intitule`) VALUES
(1, 'Salle S1'),
(2, 'Salle S2'),
(3, 'Amphi K'),
(4, 'Amphi J');

-- --------------------------------------------------------

--
-- Structure de la table `tokens`
--

CREATE TABLE `tokens` (
  `idReservation` int(11) NOT NULL,
  `Token` varchar(512) NOT NULL,
  `Expire` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tokens`
--

INSERT INTO `tokens` (`idReservation`, `Token`, `Expire`) VALUES
(1, 'b3d5d9bcc3aa1a0014dea6087bf5226cb3e6aaa0', '2022-06-27 18:13:00'),
(1, 'e90a68f94531c89249741cf4bdc50176bb0fa290', '2022-06-27 17:46:09'),
(1, 'e1978c5056287d9fa97e8fdaddaee4877e59ab6b', '2022-06-27 17:48:43'),
(1, '2af985549c426f1de61408a181dc5f26d78e3da6', '2022-06-27 17:49:04'),
(1, 'cdb6789ed31f9879a6cd1965a912f30b6e72c17d', '2022-06-27 17:54:04'),
(1, 'aecdc92627eb0086b67c64f1f415e6165068877a', '2022-06-27 17:57:32'),
(1, 'be161f6c7178f245479760c5b2894759c5c081a6', '2022-06-27 18:10:04'),
(1, '381b2ea285e62952cd0aed90169e42dc4e25490a', '2022-06-27 18:16:05'),
(5, '263607b8dd9e405b5347cae00f8abdfcf70dcd17', '2022-06-27 19:27:23'),
(6, '5018b825bfed926d19053afeaa2ff98cb2fb5eae', '2022-06-27 19:27:48'),
(6, '37f874151365c6bd53872b7b8cc836c1d63d23c6', '2022-06-27 19:34:15'),
(7, 'ae9bd01a76c18383d354891267424c0054aad0fb', '2022-06-27 19:35:45'),
(8, '346e6a3c7d1b1aaedb9fdec64ff18bf28d3b3115', '2022-06-27 19:36:25'),
(9, '4f8341b7fa1a3ec8bbb653c76049aabf75f3690a', '2022-06-27 19:37:22'),
(8, '415bd001dd0071eb39f458e072c06725d3634830', '2022-06-27 19:37:40'),
(10, '29734f978793252ce5ac01e7cec55c6b5139b51f', '2022-06-27 19:38:23'),
(11, '57e5e4b71a0245fb94ce2a58826cbff957f3eb22', '2022-06-27 19:41:20'),
(12, '97d11a7cbb15fe2050b605307488c96826968303', '2022-06-28 01:51:38'),
(13, 'c1f440757f808b90be08fd1e9cddf78a84129178', '2022-06-28 01:53:31'),
(10, 'ad34db7b3a0e99d8e5e21d94d1aabd4cc33abc13', '2022-06-28 01:54:25');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `salles`
--
ALTER TABLE `salles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT pour la table `salles`
--
ALTER TABLE `salles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

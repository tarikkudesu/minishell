function confirmation()
{
    return confirm("Voulez-vous reelement supprimer cet element?")
}
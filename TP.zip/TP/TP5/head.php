<?php
function afficherDate($lang)
{
	$moisAr = array(
    1 => 'يناير',
    2 => 'فبراير',
    3 => 'مارس',
    4 => 'أبريل',
    5 => 'مايو',
    6 => 'يونيو',
    7 => 'يوليو',
    8 => 'أغسطس',
    9 => 'سبتمبر',
    10 => 'أكتوبر',
    11 => 'نوفمبر',
    12 => 'ديسمبر'
	);

	$joursAr = array(
        "الاثنين",
        "الثلاثاء",
        "الأربعاء",
        "الخميس",
        "الجمعة",
        "السبت",
        "الأحد"
	);

	$mois = array(
    1 => 'Janvier',
    2 => 'Février',
    3 => 'Mars',
    4 => 'Avril',
    5 => 'Mai',
    6 => 'Juin',
    7 => 'Juillet',
    8 => 'Août',
    9 => 'Septembre',
    10 => 'Octobre',
    11 => 'Novembre',
    12 => 'Décembre'
	);
	$jours = array(
        "Lundi",
        "Mardi",
        "Mercredi",
        "Jeudi",
        "Vendredi",
        "Samedi",
        "Dimanche"
	);
	$monthsEn = array(
    1 => "January",
    2 => "February",
    3 => "March",
    4 => "April",
    5 => "May",
    6 => "June",
    7 => "July",
    8 => "August",
    9 => "September",
    10 => "October",
    11 => "November",
    12 => "December"
	);
	$days = [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
	    "Sunday"
	];


    switch ($lang)
	{
        case "FR":  $d= $jours[date('w')]." ".date("d")." ".$mois[date("n")]." ".date("Y") ;
		            return $d;
	    case "EN":  $d= $days[date("w")]." ".date("d")." ".$monthsEn[date("n")]." ".date("Y") ;
		            return $d;
		case "AR":  $d= $joursAr[date('w')]." ".date("d")." ".$moisAr[date("n")]." ".date("Y") ;
		            return $d;
		default :   $d= $joursAr[date('w')]." ".date("d")." ".$moisAr[date("n")]." ".date("Y") ;
		            return $d;
	}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<link rel="stylesheet" type="text/css" href="public/style.css" />
</head>
<body style="background : <?=$_COOKIE["couleur_arriere_plan"];?>; color :<?=$_COOKIE["couleur_text"];?> ">
<div class="top">
<img src= 'public/images/fsdm.jpg' border = '0' hspace = '20' vspace = '20' align = 'left' />
<span class="top">SMI6</span><br />
Facult&eacute; des Sciences Dhar El Mahraz, F&egrave;s </div>
<h4>&nbsp;<span> <?= afficherDate($_COOKIE["langue"]) ?></span></h4>
<p align="right">
<?php
if(isset($_SESSION["login"])) echo $_SESSION["login"].'  |  <a href="deconnexion.php">Déconnexion</a>';
	else echo 'non connecte '; ?> || <a href="option.php"> Option </a></p>
<br /><br />
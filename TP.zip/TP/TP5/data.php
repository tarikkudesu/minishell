<?php
// Définir le tableau d'étudiants
$etudiants[]=array("E1","Said","KROUK","SMI",19,"H",["S1","S2","S3","S4","S5"],"Said");

$etudiants[]=array("Said","4","4","SMI",4,"H",[],"4");
$etudiants[]=array("moi","moi","moi","SMI",15,"H",["S6"],"moi");
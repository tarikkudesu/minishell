<?PHP include('head.php'); ?>
<h1>Authentification</h1>
<hr id = "ligne">
<script type = "text/javascript" src="public\js.js"></script>
	<form class="form" id="form_connecte" name="form_connecte" action="verification.php" method="post">
	<label for="email" id="label_email">E-mail : </label><span id="ErrEmail"></span><br/>
	<input type="text" id="email" name="email" placeholder="votre.email@exemple.com"><br/>
	<label for="pass" id="label_pass">Mot de passe : </label><span id="ErrPass"></span><br/>
	<input type="password" id="pass" name="pass" placeholder="votre mot passe">
	<button type="submit" id="submit_con">Se connecter</button>
	<form />
	</main>
<?PHP include("bas.php");?>

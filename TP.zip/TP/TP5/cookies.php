<?php
if (isset($_POST["langue"]) && !empty($_POST["langue"])) {
  setcookie("langue", $_POST["langue"], time() + 3600 * 24 * 10, "/");
}
if (isset($_POST["couleur_text"]) && !empty($_POST["couleur_text"])) {
  setcookie("couleur_text", $_POST["couleur_text"], time() + 3600 * 24 * 10, "/");
}
if (isset($_POST["couleur_arriere_plan"]) && !empty($_POST["couleur_arriere_plan"])) {
  setcookie("couleur_arriere_plan", $_POST["couleur_arriere_plan"], time() + 3600 * 24 * 10, "/");
}
header("Location: option.php");
exit();
?>

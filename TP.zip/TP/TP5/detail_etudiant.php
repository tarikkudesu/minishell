<?php
session_start();
if (!isset($_SESSION["login"])) { include("connexion.php"); exit();}
?>
<?PHP

include("model.php"); 
$code = $_GET["code"];
$etu = getEtudiant($code);
?>
<html>
<head>
<meta charset="utf-8" />
<link rel="stylesheet" type="text/css" href="public/style.css" />
</head>
<body>
<?PHP include('head.php'); ?>
<h1>Détail  d'étudiant : <?= $etu[0]?> </h1>
<hr/>
<b> Code : <?= $etu[0]?> </b><br/><br/>
<b> Nom : <?= $etu[2]?> </b><br/><br/>
<b> Prénom : <?= $etu[1]?> </b><br/><br/>
<b> Filiere : <?= $etu[3]?> </b><br/><br/>
<b> Note : <?= $etu[4]?> </b><br/><br/>
<b> Sexe : <?= $etu[5]?> </b><br/><br/>
<b> Mot passe : <?= $etu[3]?> </b><br/><br/>
<b> Semestre validé :  </b><br/>
<ul>
<?php
foreach($etu[6] as $s )
{?>
	<li><?= $s?></li>
<?Php } ?>

<?php include('bas.php'); ?>
</body>
</html>
function valider()
{
	document.getElementById("ErrPass").innerHTML="";
    document.getElementById("ErrEmail").innerHTML ="";
	var err = false;
	if (document.form_connecte.email.value==""){
        err =true;
        document.getElementById("ErrEmail").innerHTML="Le champ est vide";
    }
	if (document.form_connecte.pass.value==""){
        err =true;
        document.getElementById("ErrPass").innerHTML="Le champ est vide";
    }
	return err;
	
}
window.addEventListener("DOMContentLoaded", function(event) {
    document.getElementById("form_connecte").addEventListener("submit", function(event) {
        if (valider()) {
            event.preventDefault();
        }
		else{}
	});
});
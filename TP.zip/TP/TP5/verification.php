<?php
$email = $_POST["email"];
$pass = $_POST["pass"];
if(!isset($_POST["email"]) || !isset($_POST["pass"]) || $_POST["email"] != "moi" || $_POST["pass"] !="douz" )
{
	header("location: connexion.php");
	exit();
}
session_start();
$_SESSION["login"]=$_POST["email"];
header("location: acceuil.php");

?>
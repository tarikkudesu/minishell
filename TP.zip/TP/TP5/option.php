<?PHP include('head.php'); ?>

<h1>Précisez vos préférences</h1>
<hr>
<form name="option" action="cookies.php" method="post">
<table align=center >
<tr> 
<td>Langue :</td>
<td><select name = "langue">
		<option  value =  "AR" "selected">العربية</option>
		<option  value =  "FR"           >Francais</option>
		<option  value =  "AN"           >Anglais</option>
		</select></td></tr> 

<tr> 
<td>Couleur de texte :</td>
<td>
<input type="radio" name ="couleur_text" value="red"/> <span style="color:red;">Rouge</span> <br/>
<input type="radio" name ="couleur_text" value="green"/> <span style="color:green;">Vert</span> <br/>
<input type="radio" name ="couleur_text" value="white"/> <span style="color:white;">Blanc</span> <br/>
<input type="radio" name ="couleur_text" value="blue"/> <span style="color:blue;">Bleu</span> <br/>
<input type="radio" name ="couleur_text" value="orange"/> <span style="color:orange;">Orange</span> <br/>
<input type="radio" name ="couleur_text" value="purple"/> <span style="color:purple;">Violet</span> <br/>

</td>
</tr> 
<tr> 
<td>Couleur d'arrier plan :</td>
<td>
<input type="radio" name="couleur_arriere_plan" value="red"/> <span style="background-color:red;">Rouge</span> <br/>
<input type="radio" name="couleur_arriere_plan" value="green"/> <span style="background-color:green;">Vert</span> <br/>
<input type="radio" name="couleur_arriere_plan" value="blue"/> <span style="background-color:blue;">Bleu</span> <br/>
<input type="radio" name="couleur_arriere_plan" value="orange"/> <span style="background-color:orange;">Orange</span> <br/>
<input type="radio" name="couleur_arriere_plan" value="purple"/> <span style="background-color:purple;">Violet</span> <br/>
<input type="radio" name="couleur_arriere_plan" value="grey"/> <span style="background-color:grey;">Gris</span> <br/>
<input type="radio" name="couleur_arriere_plan" value="white"/> <span style="background-color:white;">Blanc</span> <br/>

</td>
</tr> 
<td colspan="2" >
<input  type = 'submit'  value =  'Envoyer' /> <input  type = 'reset'  value =  'Annuler' />
</td>
<tr> 
</tr>
 
</table>
</form>
<?PHP include("bas.php");?>
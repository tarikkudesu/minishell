<?php
session_start();
if (!isset($_SESSION["login"]) || $_SESSION["login"]!="moi" ) {
	include("connexion.php");
	exit();
}
?>
<?php
include('head.php');
?>
<h1>Gestion des étudiants </h1>
<hr /><br /><br />
Bienvenue dans la page d'acceuil de notre application Web. Vous pouvez gérer d'une manière très aisée la base de données des étudiants.
En accédant à la liste, vous pouvez voir le détail d'un étudiant et le modifier ou le supprimer. A partir du menu, vous pouvez ajouter un nouveau étudiant ou afficher toute la liste. Testez!!
<br />
<?php include('bas.php'); ?>



<?php
require_once("Model.php");

function listeReservations(){		
	if($_SESSION["admin"])afficher("vListeToutesReservations.php",["Reservations"=>getAllReservations()]);
	else afficher("vListeReservations.php", ["Reservations"=>getAllActiveReservations()]);	
}
function authentifier(){
	/**	Cette action test si l'utilisateur envoie un token
		1-Si oui, on vérifie sa validité
		et selon la validité du token on accepte
		ou on rejette l'utilisateur.
	*/
	if (isset($_REQUEST["token"] )) {
		$token = $_REQUEST["token"];
		if(empty($token))    $erreur["token"] = "Token ne peut être vide !..."   ;
		if (!isset($erreur)) {		
		$user =getUserByToken($token);	 
		if(!$user) throw new Exception ("Token non valide!!..");
		$_SESSION["admin"]=ifAdmin($user);
		$_SESSION["user"]=$user;
		header("location:index.php?action=listeReservations");
		}
	}
	/** 2- Si aucun token n'est envoyé, on affiche le formulaire
		3- On le valide,
		4- et on génère un token puis l'envoyer à l'utilisateur
	*/
	if ($_SERVER["REQUEST_METHOD"]=="POST" && !isset($_REQUEST["token"] )) {	
		$email = $_POST["email"];			
		if(empty($email))    $erreur["email"] ="L'e-mail ne peut être vide !..."   ;
		elseif(substr(strtolower($email),-12,12)!="@usmba.ac.ma")    $erreur["email"] ="Utilisez votre mail académique!!..."   ;
		if (!isset($erreur)) {									
			generateUserToken($email);
			header ("location: index.php?action=listeReservations");	
		}
	}

		$data =["email" => $email  ?? "" ,
				"erreur"=> $erreur ?? ""
			   ];
		afficher ("vFormLogin.php",$data);
}


 function isValid($date, $format = 'Y-m-d'){
    $dt = DateTime::createFromFormat($format, $date);
    return $dt && $dt->format($format) === $date;
}

function index(){
	/**
		Cette action permet de gérer le formulaire
		de la figure 2
	*/
	$Reservation = ["idSalle"=>"","date"=>"","creneau"=>""];
	if ($_SERVER["REQUEST_METHOD"]=="POST") {	
	$Reservation = $_POST;
	//valider les champs du formulaire		
	if(empty($Reservation["date"]) or !isValid($Reservation["date"]) or $Reservation["date"] < Date("Y-m-d H:i:s"))  $erreur["date"] ="Date de réservation invalide !..."   ;
	elseif(empty($Reservation["creneau"]))    $erreur["creneau"] ="Choisissez un creneau !..."   ;
	elseif(empty($Reservation["idSalle"]))  $erreur["salle"] ="Choisissez une salle !..."   ;
							
	if (!isset($erreur)) {		
		$s = $Reservation["idSalle"];
		$d = $Reservation["date"];
		$c = $Reservation["creneau"];			
		if(isPossible([$s,$d,$c]))  afficher("vSalleDisponible.php",["salle"=>$s,"date"=>$d,"creneau"=>$c]);
		else                     	afficher("vSalleNonDisponible.php",["salle"=>$s,"date"=>$d,"creneau"=>$c]);
	exit;
	}
}
$data =["reservation" => $Reservation,
		"erreur"      => $erreur ?? "" ,
		"salles"      => getAllSalles()
   	];
afficher("vIndex.php", $data);
}
function reserver()
{
	extract($_POST);
	$Reservation = ["email"=>$_SESSION["user"],"motif"=>"","idSalle"=>$salle,"date"=>$date,"creneau"=>$creneau];
	AjouterReservation($Reservation);
	header("location: index.php");
	
}
function demandeSuppression()
{
	$id = $_GET["id"] ?? null;
	$user =$_SESSION["user"];
	if(empty($id)) throw new Exception ("id est vide.");
	if(!suprimmerReservation($id,$user)) throw new Exception ("La reservation n'est pas authorise.");
	header("location: index.php?action=listeReservations");
	
}
function demandeModiffier()
{
	/**
		Cette action permet de gérer le formulaire
		de la figure 2
	*/
	$Reservation = ["idSalle"=>"","date"=>"","creneau"=>""];
	if ($_SERVER["REQUEST_METHOD"]=="POST") {	
	$Reservation = $_POST;
	//valider les champs du formulaire		
	if(empty($Reservation["date"]) or !isValid($Reservation["date"]) or $Reservation["date"] < Date("Y-m-d H:i:s"))  $erreur["date"] ="Date de réservation invalide !..."   ;
	elseif(empty($Reservation["creneau"]))    $erreur["creneau"] ="Choisissez un creneau !..."   ;
	elseif(empty($Reservation["idSalle"]))  $erreur["salle"] ="Choisissez une salle !..."   ;
							
	if (!isset($erreur)) {	
		$id=$Reservation["id"];
		$s = $Reservation["idSalle"];
		$d = $Reservation["date"];
		$c = $Reservation["creneau"];			
		if(isPossible([$s,$d,$c]))  {
			modiffierReservation([$s,$d,$c,$id]);
			header("location: index.php?action=listeReservations");
			}
		else  {
			afficher("vModiffier.php",[ "reservation"=>$Reservation ,"salles"=>getAllSalles(),"isDisponible"=>"Ooops!!...Cette salle est déjà réservée !!"]);
		}
	exit;
	}
	}
	$id = $_GET["id"] ?? null;
	$user =$_SESSION["user"];
	if(empty($id)) throw new Exception ("id est vide.");
	if(!test_modiffier($id,$user)) throw new Exception ("La reservation n'est pas authorise.");
	else{
		$data= getReservationsById($id);
		afficher("vModiffier.php",[ "reservation"=>$data ,"salles"=>getAllSalles()]);
	}
}
function etatReservation()
{
	$id = $_GET["id"] ?? null;
	if(empty($id)) throw new Exception ("id est vide.");
	etatA_N($id);
	header("location: index.php?action=listeReservations");
	
}


function GenerateUserToken ($email) {
	/**
	isPossible
	ajouterUserToken
		Cette fonction utilitaire n'est pas en fait une action.
		Elle reçoit l'email d'un utilisateur et génère
		un token correspondant. Et il l'envoie à l'utilisateur
	*/
	date_default_timezone_set('Africa/Casablanca');
	$timeExpiration =  date("Y-m-d H:i:s", strtotime('+4 hours')) ; // Expire dans  4h à partir de maintenant
	$token = sha1 ($email. $timeExpiration . rand(0,999999999)) ; //une chaine aléatoire
	//insérer le token dans la BD
	ajouterUserToken([$email,$token,$timeExpiration]); 
	
	//Envoyer un email
	//$lien = "http://www.fsdm.usmba.ac.ma/ReservationSalles/index.php?action=authentifier&token=$token";
	$lien = "index.php?action=authentifier&token=$token";
	$to= $email;
	$subject = "Lien pour vous connecter" ;
	$message =" Veuillez cliquer sur le lien suivant pour vous connecter à l'application de réservations. Notez bien que ce lien va expirer le <b> : $timeExpiration </b>. <br> <a href ='$lien'>$lien</a>.<br /> Vous pouvez aussi copier/coller ce token: <b>$token</b> dans l'interface d'authentification de l'application";  
	
	
	//mail($to,$subject,$message);
	
	//affichage alternatif; juste pour tester sans utiliser l'email
	require ("Views/vEmailTest.php"); exit;
		
		
}	
function deconnexion() {
	session_destroy();
	header("location: index.php?action=listeReservations");
}
<h1>Ooops!!...Cette salle est déjà réservée !!</h1>
<hr />

<pre>

Salle : <?= $salle ?> <br />
Date : <?=  $date  ?> <br />
Creneau : <?= $creneau   ?> <br />
</pre>

<a href="index.php?action=listeReservation">Voir la liste des réservations</a> | <a href="javascript:history.go(-1)">Retour à la page précédente </a>
<br />
<br />

<h1>Testing Email</h1>

<pre>
From : FSDM Reservation System <br />
To : <?=  $to  ?> <br />
Subject : <?= $subject   ?> <br />
Message : <?=  $message  ?> <br />
﻿<div style="color: red; background-color: yellow"><h1>Erreur!! </h1>
<hr /><br />

<b>Une erreur est survenue:<br /> <?= $errorMessage ?></b> <br /><br />
</div>
<hr /><br /><br />
<b><a href ="javascript: history.go(-1)">Retour</a></b>


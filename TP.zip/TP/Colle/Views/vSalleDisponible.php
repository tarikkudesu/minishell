<h1>Cette salle est disponible</h1>
<hr />

<form action="index.php?action=reserver" method="post">

<pre>
Salle: <?= $salle ?> <input name="salle" type = "hidden" value ="<?= $salle ?>" /><br />
Date: <?=  $date  ?> <input name="date" type = "hidden" value ="<?= $date ?>" /><br />
Créneau: <?= $creneau   ?> <input name="creneau" type = "hidden" value ="<?= $creneau ?>" /><br />

<input type = "submit" value ="Réserver cette salle" /> <input type ="button" onclick="javascript:history.go(-1)" value="Retour à la page précédente" />
</pre>
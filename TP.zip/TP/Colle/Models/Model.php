﻿<?php 

function getCn(){	
	static $cn;
	if(!$cn) $cn= new PDO("mysql:host=localhost;dbname=smis6", "root", "");
	return $cn;
}

function getAllSalles(){
	return getCn()->query("select * from Salles")->fetchAll();
}

function isPossible($reservation) {
	/**	teste la disponibilité d'une salle $s
		pour une date $d et un créneau $c 
		retourn boolean 
	*/
	$Rq= getCn()->prepare("select count(*) from reservations where idSalle = ? and date = ? and creneau = ? and etat = 'Active'");
	$Rq->execute($reservation);
	return !($Rq->fetchColumn());	
}

function ajouterUserToken(array $t) {
	// insère un token dans la BD, (user est défint par son email)
	$Rq= getCn()->prepare("insert into userTokens (user,token, expire) values(?,?,?)");
	$Rq->execute($t);	
}

function getUserByToken($token){
	//retourne l'email correspondant à un token valide
	$Rq= getCn()->prepare("select user from userTokens where token = ? and Expire >= '" . Date("Y-m-d H:i:s")."'");
	$Rq->execute([$token]);
	return $Rq->fetchColumn();
}
function ifAdmin($user)
{
	$Rq= getCn()->query("SELECT email FROM administrateur WHERE email ='$user' ")->fetchColumn();
	if($user != $Rq) return false;
	else return true;
}
function getAllActiveReservations(){
	return getCn()->query("select * from Reservations where etat ='Active' and date >= '" . Date("Y-m-d H:i:s") . "'" )->fetchAll();
}
function getAllReservations(){
	return getCn()->query("select * from Reservations where  date >= '" . Date("Y-m-d H:i:s") . "'" )->fetchAll();
}
function getReservationsById($id){
	return getCn()->query("select * from Reservations where id = $id" )->fetch();
}
function AjouterReservation($R){
	$Reservation=[$R["email"],$R["motif"],$R["idSalle"],$R["date"],$R["creneau"],"Active"];
	$Rq= getCn()->prepare("insert into Reservations (email,motif,idSalle,date,creneau,etat) values(?,?,?,?,?,?)");
	$Rq->execute($Reservation);
}
function suprimmerReservation($id,$user)
{
	$Rq = getCn()->query("select email from reservations where id = $id")->fetchColumn();
	$admin = getCn()->query("select email from administrateur where email = '$user'")->fetchColumn();
	if($Rq==$user || $user==$admin){
		$Rq= getCn()->prepare("DELETE FROM Reservations WHERE id = ?");
		$Rq->execute([$id]);
		return true;
	} 
	else {
		return false;
	}
	
}
function modiffierReservation($reservation)
{
	$Rq= getCn()->prepare("UPDATE reservations SET idSalle= ? ,date= ?, creneau= ? WHERE id= ? ");
	$Rq->execute($reservation);
}
function test_modiffier($id,$user)
{
	$Rq = getCn()->query("select email from reservations where id = $id")->fetchColumn();
	$admin = getCn()->query("select email from administrateur where email = '$user'")->fetchColumn();
	if($Rq==$user || $user==$admin){
		return true;
	} 
	else {
		return false;
	}
	
}

function etatA_N($id)
{
	$Rq = getCn()->query("select etat,date,creneau from reservations where id = $id")->fetch();
	if($Rq["etat"] =="Active")
	{
		$Rq= getCn()->prepare("UPDATE reservations SET etat='Inactive' WHERE id= ? ");
		$Rq->execute([$id]);
	}
	else 
	{
		$Rq1 = getCn()->prepare("UPDATE reservations SET etat='Inactive' WHERE date = ?  and creneau = ? ");
		$Rq1->execute([$Rq["date"],$Rq["creneau"]]);
		$Rq2= getCn()->prepare("UPDATE reservations SET etat='Active' WHERE id= ?");
		$Rq2->execute([$id]);
	}
	
}
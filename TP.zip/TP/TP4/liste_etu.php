<?php
include("model.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<link rel="stylesheet" type="text/css" href="public/style.css" />
</head>

<body >
<?PHP include('head.php'); ?>
<h1>Liste des étudiants réussis de la filière: SMI</h1>
<hr />
<b>Nombre des étudiants : <?PHP echo $nbEtudiants ?></b><br />
<b>Meilleure note : <?= $maxNote ?></b> <br />
<hr />
<table border="1" align = "center" width = "60%">		
			<tr> 
				<th>Nom </th>
				<th>Prénom </th>
				<th>Note</th>
				<th>Mention</th>
			</tr>	
		 
		 <?PHP foreach($listeEtudiants as $e ) {?>
			<tr>
				<td><a href="detail_etudiant.php?code=<?= $e[0]?>"> <?PHP echo $e[1] ?></a> </td>
				<td> <a href="detail_etudiant.php?code=<?= $e[0]?>"> <?PHP echo $e[2] ?> </a> </td>
				<td><a href="detail_etudiant.php?code=<?= $e[0]?>">  <?PHP echo $e[4] ?> </a> </td>
				<td> <a href="detail_etudiant.php?code=<?= $e[0]?>"> <?PHP echo getMention($e[4])  ?> </a></td>
			</tr>
			
			
		 <?PHP }?>
          <tr>
		  <td colspan="4" style="text-align: center"><a  href="form.php" >Ajouter</a></td>
		  </tr>
</table>



<?php include('bas.php'); ?>




</body>
</html>
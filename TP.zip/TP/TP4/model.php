<?php
include("data.php");
// Définir la constante MOY_REUSSITE
define("MOY_REUSSITE", 10);

// Fonction pour récupérer une liste d'étudiants réussis pour une filière donnée
function getListeParFiliere($filiere) {
    global $etudiants;
    $liste = array();
    foreach ($etudiants as $etudiant) {
        if ($etudiant[3] == $filiere && $etudiant[4] >= MOY_REUSSITE) {
            $liste[] = $etudiant;
        }
    }
    return $liste;
}
function getMax($t) {
	$max =0;
	$n = count($t); 
	for ($i = 0; $i < $n; $i++) {
		if ($t[$i] > $max) 
			$max = $t[$i];
	}
	return $max;
}

function getMention($note) {
  
 
if ($note >= 16) {
    
   
return "Très bien";
  } 
 
elseif ($note >= 14) {
    return "Bien";
  } 
 
elseif ($note >= 12) {
    return "Assez bien";
  } 
 
elseif ($note >= 10) {
    
   
return "Passable";
  } else {
    return "Ajourné";
  }
}

function getMeilleureNote() {
  global $etudiants;
  $notes = array();
  foreach ($etudiants as $etudiant) {
    $notes[] = $etudiant[4];
  }
  $meilleureNote = getMax($notes);
  return $meilleureNote;
}
function getMeilleureNoteParFiliere($filiere){
  $etudiants=getListeParFiliere($filiere);
  $notes = array();
  foreach ($etudiants as $etudiant) {
    $notes[] = $etudiant[4];
  }
  $meilleureNote = getMax($notes);
  return $meilleureNote;
}
function getEtudiant($code)
{
	global $etudiants;
	foreach ( $etudiants as $etudiant)
	{
		if($etudiant[0]==$code) return $etudiant;
	}
	
}
//  calcule des valeurs a affiche

$listeEtudiants = $etudiants;
$nbEtudiants = count($listeEtudiants);
$maxNote = getMeilleureNote();
?>
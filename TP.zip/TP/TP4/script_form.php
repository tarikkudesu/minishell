<?php
//phpinfo();
$nom =$_POST["Nom"];
$prenom=$_POST["Prenom"];
$code=$_POST["Code"];
$filiere=$_POST["Filiere"];
$note=$_POST["Note"];
$checkbox=$_POST["SV"];
$radio =$_POST["Sexe"];
$pass =$_POST["Pass"];
//////////////////////////////
$i=0;
foreach ($checkbox as $ck) {
	if($i==0)
		$c='"'.$ck.'"';
	else
		$c=$c.','.'"'.$ck.'"';
	$i++;
}
$s= "\n".'$etudiants[]=array("'.$code.'","'.$prenom.'","'.$nom.'","'.$filiere.'",'.$note.',"'.$radio.'"'.",[".$c."],".'"'.$pass.'");';
$id = fopen("data.php","a");
fputs($id,$s);
//file_put_contents('data.php',$s, FILE_APPEND);
header("location: form.php");
unset($_POST);
?>
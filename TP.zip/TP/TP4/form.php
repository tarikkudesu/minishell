<?php include("model.php"); ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<link rel="stylesheet" type="text/css" href="public/style.css" />
<script type = "text/javascript" src="public\Javascript1.js"></script>
</head>
<body >
<?PHP include('head.php'); ?>
<h1>Ajouter un étudiant</h1>
<hr />

<!-- l'attribut name permet d'accèder facilement au formulaire -->

<form id = "myForm" name = "myForm" action = "script_form.php" method = "post" >

<pre>
<!-- chaque  élément de formulaire à un attribut name -->
Entrez le code:              
<input type="text" name="Code" value=""/> <span class="Err" id="ErrCode"> </span>

Entrez le nom:
<input  type="text"  name="Nom" value="" /> <span class="Err" id="ErrNom"> </span>

Entrez le prénom:
<input type="text" name="Prenom" value="" /> <span class="Err" id="ErrPrenom"> </span>

Entrez la Note :
<input type="text" name ="Note" value="" /> <span class="Err" id="ErrNote"> </span>

Entrez mot pass :
<input type="password" name ="Pass" value="" /><span class="Err" id="ErrPass"> </span>
<!-- Un seule nom pour la liste, chaque élément de la liste a une "Value" -->
Filière:
<select name = "Filiere">
		<option  value =  "SMI" "selected">Sciences Mathématiques et Informatique</option>
		<option  value =  "SMA"           >Sciences Mathématiques et Application</option>
		<option  value =  "SMP"           >Sciences de la Matière Physique</option>
		<option  value =  "SVI"           >Sciences de la vie</option>
		</select> <span class="Err"> </span>
<br/>
<input  type = 'radio'  name="Sexe" value =  'H' > Homme</input> <span class="Err" id="ErrSexe"> </span>
<input  type = 'radio'  name="Sexe" value =  'F' > Femme</input>
<br/>
<input  type = "checkbox"  name =  "SV[]"  value = "S1"   /> S1
<input  type = "checkbox"  name =  "SV[]"  value = "S2"   /> S2
<input  type = "checkbox"  name =  "SV[]"  value = "S3"   /> S3
<input  type = "checkbox"  name =  "SV[]"  value = "S4"   /> S4
<input  type = "checkbox"  name =  "SV[]"  value = "S5"   /> S5
<input  type = "checkbox"  name =  "SV[]"  value = "S6"   /> S6
<br/>

<input  type = 'submit'  value =  'Envoyer' /> <input  type = 'reset'  value =  'Annuler' />
</pre>
</form>


<?php include('bas.php'); ?>

</body>
</html>


<?php
include("model.php");
//  calcule des valeurs a affiche

$filiere_f= $_GET['filier'];
$listeEtudiants_f = getListeParFiliere($filiere_f);
$nbEtudiants_f = count($listeEtudiants_f);
$maxNote_f = getMeilleureNoteParFiliere($filiere_f);



?>

<!-- Designed and developped by Ahmed ZINEDINE (ahmedzinedine[at]yahoo[dot]com) --> 
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<link rel="stylesheet" type="text/css" href="public/style.css" />
<script type = "text/javascript" src="public\JS.js"></script>
</head>

<body >
<?PHP include('head.php'); ?>
<h1>Liste des étudiants réussis de la filière: <?PHP echo $filiere_f ?></h1>
<hr />
<b>Nombre des étudiants : <?PHP echo $nbEtudiants_f ?></b><br />
<b>Meilleure note : <?PHP echo $maxNote_f ?></b> <br />
<hr />
<table border="1" align = "center" width = "60%">		
			<tr> 
				<th>Nom </th>
				<th>Prénom </th>
				<th>Note</th>
				<th>Mention</th>
			</tr>	
		 
		 <?PHP foreach($listeEtudiants_f as $e ) {?>
			<tr>
				<td><a href="detail_etudiant.php?code=<?= $e[0]?>"> <?PHP echo $e[1] ?></a> </td>
				<td> <a href="detail_etudiant.php?code=<?= $e[0]?>"> <?PHP echo $e[2] ?> </a> </td>
				<td><a href="detail_etudiant.php?code=<?= $e[0]?>">  <?PHP echo $e[4] ?> </a> </td>
				<td> <a href="detail_etudiant.php?code=<?= $e[0]?>"> <?PHP echo getMention($e[4])  ?> </a></td>
			</tr>	
		 <?PHP }?>

</table>
<?php include('bas.php'); ?>
</body>
</html>
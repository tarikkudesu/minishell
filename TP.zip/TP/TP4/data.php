<?php
// Définir le tableau d'étudiants
$etudiants[]=array("E1","Said","KROUK","SMI",19,"H",["S1","S2","S3","S4","S5"],"Said");

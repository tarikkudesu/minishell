<?php
function afficherDate($lang) {
	$mois = array(
    1 => 'Janvier',
    2 => 'Février',
    3 => 'Mars',
    4 => 'Avril',
    5 => 'Mai',
    6 => 'Juin',
    7 => 'Juillet',
    8 => 'Août',
    9 => 'Septembre',
    10 => 'Octobre',
    11 => 'Novembre',
    12 => 'Décembre'
	);
	$jours = array(
    0 => "Lundi",
    1 => "Mardi",
    2 => "Mercredi",
    3 => "Jeudi",
    4 => "Vendredi",
    5 => "Samedi",
    6 => "Dimanche"
	);
	$monthsEn = array(
    1 => "January",
    2 => "February",
    3 => "March",
    4 => "April",
    5 => "May",
    6 => "June",
    7 => "July",
    8 => "August",
    9 => "September",
    10 => "October",
    11 => "November",
    12 => "December"
	);
	$days = [
    
    0 => "Monday",
    1 => "Tuesday",
    2 => "Wednesday",
    3 => "Thursday",
    4 => "Friday",
    5 => "Saturday",
	6 => "Sunday"
	];


    switch ($lang)
	{
        case "FR":  $d= $jours[date('w')]." ".date("d")." ".$mois[date("n")]." ".date("Y") ;
		            return $d;
	    case "EN":  $d= $days[date("w")]." ".date("d")." ".$monthsEn[date("n")]." ".date("Y") ;
		            return $d;
		
		
	}
}
?>
<div class="top">
<img src= 'public/images/fsdm.jpg' border = '0' hspace = '20' vspace = '20' align = 'left' />
<span class="top">SMI6</span><br />
Facult&eacute; des Sciences Dhar El Mahraz, F&egrave;s </div>
<h4>&nbsp;<span> <?PHP echo afficherDate("FR") ?></span></h4>
<br /><br />

<?php
// Définir la constante MOY_REUSSITE
define("MOY_REUSSITE", 10);
function getMention($note) {
  
 
if ($note >= 16) {
    
   
return "Très bien";
  } 
 
elseif ($note >= 14) {
    return "Bien";
  } 
 
elseif ($note >= 12) {
    return "Assez bien";
  } 
 
elseif ($note >= 10) {
    
   
return "Passable";
  } else {
    return "Ajourné";
  }
}
// Fonction pour récupérer une liste d'étudiants réussis pour une filière donnée
function ouvrirConexion()
{ 
	static $cn;
	if(!$cn){
		$user = 'root';
		$password = '';
		$db = 'mysql:host=localhost:3306;dbname=SMIS6';
		$cn =new PDO($db, $user, $password);
	}
	return $cn;
}
function getAll($table)
{
	return ouvrirConexion()->query("select * from $table ")->fetchAll();
}
function getOne($table, $id)
{
	$rq = ouvrirConexion()->prepare("SELECT * FROM $table WHERE id = ?");
	$rq->execute([$id]);
	return $rq->fetch(); 
}
function getAllCriteria ($table, $criteria)
{
	$rq = ouvrirConexion()->prepare("SELECT * FROM $table WHERE $criteria");
    $rq->execute();
    return $rq->fetchAll();
}

function AjouterEtudiant($e)
{
	$rq = ouvrirConexion()->prepare("INSERT INTO Etudiant VALUES (?,?,?,?,?)");
	$rq->execute([NULL, $e[0], $e[1], $e[2], $e[3], $e[4]]);
}
function SupprimerEtudiant($id)
{
	$rq = ouvrirConexion()->prepare("DELETE FROM etudiant WHERE id = ?");
	$rq->execute();
}
function ModifierEtudiant($id,$e) {
	$rq = ouvrirConexion()->prepare("UPDATE etudiant SET CodeE = ? ',Nom = ? ,Prenom = ? ,Filiere = ?,Note = ? WHERE id = ?")
	$rq->execute([$e[0], $e[1], $e[2], $e[3], $e[4], $id]);
}
?>
<?php
include("model.php"); 
$id=$_GET["id"];
SupprimerEtudiant($id);
header("location: liste_etu.php");
?>
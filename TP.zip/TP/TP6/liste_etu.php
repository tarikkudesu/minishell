<?php
include("model.php");
?>
<?PHP include('head.php'); ?>
<h1>Liste des étudiants réussis de la filière: SMI</h1>
<hr />
<b>Nombre des étudiants : <?PHP echo count( getAll ('Etudiant')) ?></b><br />
<b>Meilleure note : </b> <br />
<hr />
<table border="1" align = "center" width = "60%">		
			<tr> 
				<th>Nom </th>
				<th>Prénom </th>
				<th>Note</th>
				<th>Mention</th>
			</tr>	
		 
		 <?PHP foreach(getAll('Etudiant') as $e ) {?>
			<tr>
				<td><a href="detail_etudiant.php?id=<?=$e["id"]?>"> <?PHP echo $e[2] ?></a> </td>
				<td> <a href="detail_etudiant.php?id=<?=$e["id"]?>"> <?PHP echo $e[3] ?> </a> </td>
				<td><a href="detail_etudiant.php?id=<?=$e["id"]?>">  <?PHP echo $e[5] ?> </a> </td>
				<td> <a href="detail_etudiant.php?id=<?=$e["id"]?>"> <?PHP echo getMention($e[5])  ?> </a></td>
			</tr>
			
			
		 <?PHP }?>
          <tr>
		  <td colspan="4" style="text-align: center"><a  href="form.php" >Ajouter</a></td>
		  </tr>
</table>



<?php include('bas.php'); ?>




</body>
</html>
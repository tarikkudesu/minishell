<?php
include("model.php");
//  calcule des valeurs a affiche

$filiere= $_GET['filier'];
$listeEtudiants_f =getListeEtudiantFilieres('Etudiant', 'Filiere = '.$filiere);
$nbEtudiants_f = count($listeEtudiants_f);
//$maxNote_f = getMeilleureNoteParFiliere($filiere_f);
?>

<?PHP include('head.php'); ?>
<h1>Liste des étudiants réussis de la filière: <?PHP echo $filiere?></h1>
<hr />
<b>Nombre des étudiants : <?PHPecho $nbEtudiants_f ?></b><br />
<b>Meilleure note : </b> <br />
<hr />
<table border="1" align = "center" width = "60%">		
			<tr> 
				<th>Nom </th>
				<th>Prénom </th>
				<th>Note</th>
				<th>Mention</th>
			</tr>	
		 
		 <?PHP foreach($listeEtudiants_f as $e ) {?>
			<tr>
				<td><a href="detail_etudiant.php?id=<?=$e["id"]?>"> <?PHP echo $e[2] ?></a> </td>
				<td> <a href="detail_etudiant.php?id=<?=$e["id"]?>"> <?PHP echo $e[3] ?> </a> </td>
				<td><a href="detail_etudiant.php?id=<?=$e["id"]?>">  <?PHP echo $e[5] ?> </a> </td>
				<td> <a href="detail_etudiant.php?id=<?=$e["id"]?>"> <?PHP echo getMention($e[5])  ?> </a></td>
			</tr>
		 <?PHP }?>

</table>
<?php include('bas.php'); ?>
</body>
</html>
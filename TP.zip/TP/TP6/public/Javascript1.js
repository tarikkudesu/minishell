function validerLeFormulaire() {
    var err = false;
    document.getElementById("ErrCode").innerHTML ="";
    document.getElementById("ErrNom").innerHTML ="";
    document.getElementById("ErrPrenom").innerHTML ="";
    document.getElementById("ErrNote").innerHTML ="";
	 
    if (document.myForm.Code.value==""){
        err =true;
        document.getElementById("ErrCode").innerHTML="Le code est obligatoire";
    }
    if (document.myForm.Nom.value==""){
        err =true;
        document.getElementById("ErrNom").innerHTML="Le nom est obligatoire";
    }
    if (document.myForm.Prenom.value==""){
        err = true;
        document.getElementById("ErrPrenom").innerHTML="Le prénom est obligatoire";
    }
	
    if (document.myForm.Note.value==""){
        err = true;
        document.getElementById("ErrNote").innerHTML="La note est obligatoire";
    } else if (isNaN(document.myForm.Note.value)){
        err = true;
        document.getElementById("ErrNote").innerHTML="La note doit être un nombre";
    } else if (parseFloat(document.myForm.Note.value) < 0 || parseFloat(document.myForm.Note.value) > 20){
        err = true;
        document.getElementById("ErrNote").innerHTML="La note doit être entre 0 et 20";
    }
	
    return err;
}

window.addEventListener("DOMContentLoaded", function(event) {
    document.myForm.addEventListener("submit", function(event) {
        if (validerLeFormulaire()) {
            event.preventDefault();
        } else {
            alert("Les données vont être envoyées");
        }
    });
});

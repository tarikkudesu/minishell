<?PHP include('head.php'); ?>
<?PHP
include("model.php"); 
$e=getDetailEtudiant($_GET["id"]);
?>
<h1>Détail  d'étudiant : <?=$e["id"]?> </h1>
<hr/>
<b> Code : <?= $e["CodeE"]?> </b><br/><br/>
<b> Nom : <?= $e[2]?> </b><br/><br/>
<b> Prénom : <?= $e[3]?> </b><br/><br/>
<b> Filiere : <?= $e[4]?> </b><br/><br/>
<b> Note : <?= $e[5]?> </b><br/><br/>
<ul>
<pre><b><a href="Supprimer.php?id=<?=$e['id']?>">Supprimer </a> | <a href="script_form.php?Modifer=True&id=<?=$e['id']?>">Modifier</a></b></pre>
<?php include('bas.php'); ?>
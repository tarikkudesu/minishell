<?php
include("model.php");
if(isset($_GET["Modifier"]) && $_GET["Modifier"]=True && isset($_GET["id"]))
{
	ModifierEtudiant($id,$e);
	header("location: form.php");
	exit;
}

AjouterEtudiant(array($_POST["Code"],$_POST["Nom"],$_POST["Prenom"],$_POST["Filiere"],$_POST["Note"]));
header("location: form.php");
?>
<!-- Designed and developped by Ahmed ZINEDINE (ahmedzinedine[at]yahoo[dot]com) --> 
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<link rel="stylesheet" type="text/css" href="public/style.css" />

</head>
<body >
<?PHP include('head.php'); ?>
<h1>Ajouter un étudiant</h1>
<hr />

<!-- l'attribut name permet d'accèder facilement au formulaire -->

<form id = "myForm" name = "myForm" action = "script.php" method = "post">

<pre>
<!-- chaque  élément de formulaire à un attribut name -->
Entrez le code:              
<input type="text" name="Code" value=""/> <span class="Err" id="ErrCode"> </span>


Entrez le nom:
<input  type="text"  name="Nom" value="" /> <span class="Err" id="ErrNom"> </span>

Entrez le prénom:
<input type="text" name="Prenom" value="" /> <span class="Err" id="ErrPrenom"> </span>

Entrez la Note
<input type="text" name ="Note" value="" /> <span class="Err" id="ErrNote"> </span>
<!-- Un seule nom pour la liste, chaque élément de la liste a une "Value" -->
Filière:
<select name = "Filiere">
		<option  value =  "SMI" "selected">Sciences Mathématiques et Informatique</option>
		<option  value =  "SMA"           >Sciences Mathématiques et Application</option>
		<option  value =  "SMP"           >Sciences de la Matière Physique</option>
		</select> <span class="Err"> </span>

<input  type = 'submit'  value =  'Envoyer' /> <input  type = 'reset'  value =  'Annuler' />
</pre>
</form>
<?php include('bas.php'); ?>
</body>
</html>

<!-- Designed and developped by Ahmed ZINEDINE (ahmedzinedine[at]yahoo[dot]com) --> 
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<link rel="stylesheet" type="text/css" href="public/style.css" />
<script type = "text/javascript" src="public\JS.js"></script>

</head>

<body >
<?PHP include('head.php'); ?>
<h1>Gestion des étudiants </h1>
<hr /><br /><br />
Bienvenue dans la page d'acceuil de notre application Web. Vous pouvez gérer d'une manière très aisée la base de données des étudiants.
En accédant à la liste, vous pouvez voir le détail d'un étudiant et le modifier ou le supprimer. A partir du menu, vous pouvez ajouter un nouveau étudiant ou afficher toute la liste. Testez!!
<br />
<?php include('bas.php'); ?>
</body>
</html>



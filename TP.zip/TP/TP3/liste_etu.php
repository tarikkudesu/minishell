<?php
// Définir le tableau d'étudiants
$etudiants = array(
    array("Moujtahid","Moujidd","SMI",18),
    array("Kaddouri","Kaddour","SMI",15),
    array("mohammed","aalala","SMA",12),
    array("ismail","souli","SMI",8),
    array("hamza","hamzawi","SMP",14),
    array("said","saad","SMA",17),
);

// Définir la constante MOY_REUSSITE
define("MOY_REUSSITE", 10);

// Fonction pour récupérer une liste d'étudiants réussis pour une filière donnée
function getListeParFiliere($filiere) {
    global $etudiants;
    $liste = array();
    foreach ($etudiants as $etudiant) {
        if ($etudiant[2] == $filiere && $etudiant[3] >= MOY_REUSSITE) {
            $liste[] = $etudiant;
        }
    }
    return $liste;
}
function getMax($t) {
	$max =0;
	$n = count($t); 
	for ($i = 0; $i < $n; $i++) {
		if ($t[$i] > $max) 
			$max = $t[$i];
	}
	return $max;
}

function getMention($note) {
  
 
if ($note >= 16) {
    
   
return "Très bien";
  } 
 
elseif ($note >= 14) {
    return "Bien";
  } 
 
elseif ($note >= 12) {
    return "Assez bien";
  } 
 
elseif ($note >= 10) {
    
   
return "Passable";
  } else {
    return "Ajourné";
  }
}

function getMeilleureNote() {
  global $etudiants;
  $notes = array();
  foreach ($etudiants as $etudiant) {
    $notes[] = $etudiant[3];
  }
  $meilleureNote = getMax($notes);
  return $meilleureNote;
}
//  calcule des valeurs a affiche

$listeEtudiants = $etudiants;
$nbEtudiants = count($listeEtudiants);
$maxNote = getMeilleureNote();



?>

<!-- Designed and developped by Ahmed ZINEDINE (ahmedzinedine[at]yahoo[dot]com) --> 
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<link rel="stylesheet" type="text/css" href="public/style.css" />
</head>

<body >
<?PHP include('head.php'); ?>
<h1>Liste des étudiants réussis de la filière: SMI</h1>
<hr />
<b>Nombre des étudiants : <?PHP echo $nbEtudiants ?></b><br />
<b>Meilleure note : <?PHP echo $maxNote ?></b> <br />
<hr />
<table border="1" align = "center" width = "60%">		
			<tr> 
				<th>Nom </th>
				<th>Prénom </th>
				<th>Note</th>
				<th>Mention</th>
			</tr>	
		 
		 <?PHP foreach($listeEtudiants as $e ) {?>
			<tr>
				<td> <?PHP echo $e[0] ?> </td>
				<td>  <?PHP echo $e[1] ?>  </td>
				<td>  <?PHP echo $e[3] ?>  </td>
				<td>  <?PHP echo getMention($e[3])  ?> </td>
			</tr>	
		 <?PHP }?>

</table>



<?php include('bas.php'); ?>




</body>
</html>
<br />
<hr />
<a href ="acceuil.php">Acceuil</a> |
<a href ="liste_etu.php">Liste de étudiants</a> |
<a href ="form.php">Ajouter un étudiant</a> |
<a href ="liste_filier.php">Liste des filier</a>
<br /><hr /><br />
<div class="bas">&copy; copyright: SMI6 2023<br />Facult&eacute; des Sciences Dhar El Mahraz</br>smi6@fsdm.usmba.ac.ma</div>
<?php
 include("models/EtudiantManager.php");
 
 function ListeFAction($id=NULL)
 {
	render("Views/vListeFiliere.php",["filiere"=>getTable("filiere")]);
 }
 function ListeEAction($id=NULL)
 {
 render("Views/vListeEtudiant.php",["Etudiant"=>getTable("etudiant"),'Note'=>getMeilleureNote($id)]);
 }
 function indexAction($id=NULL)
 {
 render("Views/index.php");
 
 }
 function AjouterEAction($id=NULL)
 {
 render("Views/vAjouterEtudiant.php");
 }
 function DetailEAction($id=NULL)
 {
 render("Views/vDetailEtudiant.php",['Etudiant'=>findOne("Etudiant",$id),'Filiere'=>getTable('Filiere')]);
 }
 function ListeEFAction($id=NULL)
 {
 render("Views/vListeEtudiant.php",['Etudiant'=>getListeParFiliere($id),'Note'=>getMeilleureNoteParFiliere($id)]);
 }
 function SupprimerAction($id=NULL) {
	SupprimerEtudiant($id);
	ListeEAction($id);
}
 
function render($view, array $variables = [])
{
    extract($variables);
    ob_start();
    require($view);
    $views = ob_get_contents();
    ob_end_clean();
    require("Views/Template/template0.php");
}
<?php
include("Controllers/EtudiantController.php");
try {
    $id = $_GET["id"] ?? NULL;
    $action = $_GET["action"] ?? "index";
    $action = $action . "Action";
    if (!is_callable($action)) {
        throw new Exception("Action non autorisée");
    }
    $action();
} catch (Exception $e) {
    $view= "Views/vErreur.php";
	$variables=["message"=> $e->getMessage()];
	render($view, $variables);
	
}
<?php include("Views/head.php");?>
<main id="main_template">
<?=$views?>
</main>
<?php include("Views/bas.php");?>
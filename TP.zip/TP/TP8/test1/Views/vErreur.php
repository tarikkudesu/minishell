<?php
/*vue 
	$view = "vError.php";
	$variables["message"]


*/

?>


<div style="color: green; background-color: red"><h1>Erreur!! </h1>
<hr /><br />

<b>Une erreur est survenue: <?= $variables["message"] ?></b> <br /><br />
</div>
<hr /><br /><br />
<b><a href ="javascript: history.go(-1)">Retour</a></b>
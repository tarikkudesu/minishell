<?php
 include("models/EtudiantManager.php");
 
 function ListeFAction()
 {
	render("Views/vListeFiliere.php",["filiere"=>getTable("filiere")]);
 }
 function ListeEAction()
 {
	render("Views/vListeEtudiant.php",["Etudiant"=>getTable("etudiant"),'Note'=>getMeilleureNote()]);
 }
 function indexAction()
 {
	render("Views/index.php");
 
 }
 function AjouterEAction()
 {
 render("Views/vAjouterEtudiant.php");
 }
 function DetailEAction()
 {
	 $id = $_GET["id"] ?? "";
	 if (empty($id)) throw new Exception ("Vous n'avez pas fourni l'id de l'étudiant voulu!!") ;
	if (!is_numeric($id)) throw new Exception ("l'id fourni est non valide!!") ;
 render("Views/vDetailEtudiant.php",['Etudiant'=>findOne("Etudiant",$id),'Filiere'=>getTable('Filiere')]);
 }
 function ListeEFAction()
 {
	 $id = $_GET["id"] ?? "";
	 if (empty($id)) throw new Exception ("Vous n'avez pas fourni l'id de l'étudiant voulu!!") ;
	if (!is_numeric($id)) throw new Exception ("l'id fourni est non valide!!") ;
 render("Views/vListeEtudiant.php",['Etudiant'=>getListeParFiliere($id),'Note'=>getMeilleureNoteParFiliere($id)]);
 }
 function SupprimerAction() {
	$id = $_GET["id"] ?? "";
	if (empty($id)) throw new Exception ("Vous n'avez pas fourni l'id de l'étudiant voulu!!") ;
	if (!is_numeric($id)) throw new Exception ("l'id fourni est non valide!!") ;
	SupprimerEtudiant($id);
	ListeEAction($id);
}
 
function render($view, array $variables = [])
{
    extract($variables);
    ob_start();
    require($view);
    $views = ob_get_contents();
    ob_end_clean();
    require("Views/Template/template0.php");
}
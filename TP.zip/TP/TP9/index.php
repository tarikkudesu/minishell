<?php
include("Controllers/EtudiantController.php");
try {
	
	session_start();
	
	//(isset($_COOKIE["userLogin"])) $_SESSION["Login"]= $_COOKIE["userLogin"];
	//if(isset($_COOKIE["userToken"]) && session_exists($_COOKIE["userToken"])) $_SESSION["Login"]= session_exists($_COOKIE["userToken"]);
	if(empty($_SESSION["Login"]) ) {login(); exit();}
    $id = $_GET["id"] ?? NULL;
    $action = $_GET["action"] ?? "index";
    $action = $action . "Action";
    if (!is_callable($action)) {
        throw new Exception("Action non autorisée");
    }
    $action();
} catch (Exception $e) {
    $view= "Views/vErreur.php";
	$variables=["message"=> $e->getMessage()];
	render($view, $variables);
	
}
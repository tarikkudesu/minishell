<?php
 include("models/EtudiantManager.php");
 
 function ListeFAction()
 {
	render("Views/vListeFiliere.php",["filiere"=>getTable("filiere")]);
 }
 function ListeEAction()
 {
	render("Views/vListeEtudiant.php",["Etudiant"=>getTable("etudiant"),'Note'=>getMeilleureNote()]);
 }
 function indexAction()
 {
	render("Views/index.php");
 
 }
 function DetailEAction()
 {
	$id = $_GET["id"] ?? "";
	if (empty($id)) throw new Exception ("Vous n'avez pas fourni l'id de l'étudiant voulu!!") ;
	if (!is_numeric($id)) throw new Exception ("l'id fourni est non valide!!") ;
	$Etudiant=findOne("Etudiant",$id);
	$Filiere =findOne('filiere',$Etudiant['Filiere']);
	render("Views/vDetailEtudiant.php",['Etudiant'=>$Etudiant,'Filiere'=>$Filiere]);
 }
 function ListeEFAction()
 {
	$id = $_GET["id"] ?? "";
	if (empty($id)) throw new Exception ("Vous n'avez pas fourni l'id de l'étudiant voulu!!") ;
	if (!is_numeric($id)) throw new Exception ("l'id fourni est non valide!!") ;
 render("Views/vListeEtudiant.php",['Etudiant'=>getListeParFiliere($id),'Filiere'=>findOne("Filiere",$id),'Note'=>getMeilleureNoteParFiliere($id)]);
 }
 function SupprimerAction() {
	$id = $_GET["id"] ?? "";
	if (empty($id)) throw new Exception ("Vous n'avez pas fourni l'id de l'étudiant voulu!!") ;
	if (!is_numeric($id)) throw new Exception ("l'id fourni est non valide!!") ;
	SupprimerEtudiant($id);
	render("Views/index.php");
}

function editAction() {	

	if ($_SERVER["REQUEST_METHOD"]=="POST") {
		$etudiant=$_POST;
		if(empty($etudiant["CodeE"]))   $erreur["CodeE"]   ="Le code est vide !..."   ;
		if(empty($etudiant["Nom"]))    $erreur["Nom"]    ="Le Nom est vide !...."   ;
		if(empty($etudiant["Prenom"]))  $erreur["Prenom"] ="Le prénom est vide !..." ;
		if(empty($etudiant["Filiere"])) $erreur["Filiere"]="Sélectionnez une filière !...";
		
		if(empty($etudiant["Note"]))
			$erreur["Note"]="La Note est vide !...";
		elseif(!is_Numeric($etudiant["Note"]))
			$erreur["Note"]="La Note doit être un un nombre !...";
		elseif($etudiant["Note"] < 0 or $etudiant["Note"] > 20)
			$erreur["Note"]="La Note doit être entre 0 et 20 !...";
		if (!isset($erreur)) {
			
			save("Etudiant",$etudiant);
			header ("location: index.php?action=listeE");
		} 
	}
	else {
		
		$id = $_GET["id"] ?? Null;
		 
		$etudiant = empty($id) ? NULL : findOne("etudiant",$id);
		$erreur = Null ;
		
	}
	
	$view = empty($id) ? "Views/vAjouter.php" : "Views/vModifier.php" ;
	
	$variabls = ["etudiant" => $etudiant,
				 "erreur"   => $erreur ,
				 "Filiere" => getTable("filiere")
				];	
		
	render($view,$variabls);
}



function login(){
	$user =["Login"=>"","PW"=>""];
	if ($_SERVER["REQUEST_METHOD"]=="POST") {
		$user =	$_POST;
		//valider les champs du formulaire		
		if(empty($user["Login"]))  $erreur["Login"] ="Le login est vide !..."   ;
		elseif(empty($user["PW"]))  $erreur["PW"] ="Le mot de passe est vide !..."   ;		
		elseif(!existe_user($user['Login'],$user['PW'])) $erreur["User"]= "Login ou mot de passe incorrect!...";
		if (!isset($erreur)) {
			
				$_SESSION["Login"]= $user["Login"];
				header ("location: index.php");
				//le reste du script ne sera pas exécuté, dans ce cas
		}
	}
	
	$variables["erreur"]= $erreur ?? [];
	render("Views/vFormLogin.php", $variables);
}


function deconnexionAction(){
	session_destroy();
	setCookie("userToken","",time() - 1);
	header ("location: index.php");
}






































 
function render($view, array $variables = [])
{
    extract($variables);
    ob_start();
    require($view);
    $views = ob_get_contents();
    ob_end_clean();
    require("Views/Template/template0.php");
}






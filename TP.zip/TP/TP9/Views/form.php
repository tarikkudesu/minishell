<form name = "myForm" action = "" method = "post">
<input type="hidden" name="id" value="<?= $etudiant["id"] ?? '' ?>"/>
<pre>

<!-- chaque  élément de formulaire à un attribut name -->
Entrez le code:              
<input type="text" name="CodeE" value="<?= $etudiant["CodeE"] ?? '' ?>"/> <span class="Err"><?= $erreur["CodeE"] ?? "" ?> </span>

Entrez le nom:
<input  type="text"  name="Nom" value="<?= $etudiant["Nom"] ?? '' ?>" /> <span class="Err"><?= $erreur["Nom"] ?? "" ?> </span>

Entrez le prénom:
<input type="text" name="Prenom" value="<?= $etudiant["Prenom"] ?? '' ?>" /> <span class="Err"><?= $erreur["Prenom"] ?? "" ?> </span>

Entrez la Note
<input  type="text" name ="Note" value="<?= $etudiant["Note"] ?? '' ?>" /> <span class="Err"><?= $erreur["Note"] ?? "" ?> </span>


Filière:
<select name = "Filiere">
		<option value="">---</option>

		<?php 

		foreach ($Filiere as $f) { ?>

		<option  value =  "<?= $f['id'] ?>" 

		<?php($f['id']==$etudiant["Filiere"])? "selected":"" ?>

		 <?= $f["NomF"] ?></option>


		<?php } ?>
			
		</select> <span class="Err"><?= $erreur["Filiere"] ?? "" ?> </span>

<input  type = 'submit'  value =  'Envoyer' /> <input  type = 'reset'  value =  'Annuler' />
</pre>
</form>

<h1>Liste des étudiants   <?PHP  
if(isset($_GET["id"])) echo "par filiere : ". $Filiere["CodeF"] ;
else echo " : "; ?></h1>
<hr />
<b>Nombre des étudiants : <?PHP echo count($Etudiant) ?></b><br />
<b>Meilleure note : <?=$Note?> </b> <br />
<hr />
<table border="1" align = "center" width = "60%">		
			<tr> 
				<th>Nom </th>
				<th>Prénom </th>
				<th>Note</th>
				<th>Mention</th>
			</tr>	
		 
		 <?PHP foreach($Etudiant as $e ) {?>
			<tr>
				<td><a href="index.php?action=DetailE&id=<?=$e["id"]?>"> <?PHP echo $e[2] ?></a> </td>
				<td><a href="index.php?action=DetailE&id=<?=$e["id"]?>"> <?PHP echo $e[3] ?> </a> </td>
				<td><a href="index.php?action=DetailE&id=<?=$e["id"]?>"> <?PHP echo $e[5] ?> </a> </td>
				<td><a href="index.php?action=DetailE&id=<?=$e["id"]?>"> <?PHP echo getMention($e[5])  ?> </a></td>
			</tr>
			
			
		 <?PHP }?>
</table>


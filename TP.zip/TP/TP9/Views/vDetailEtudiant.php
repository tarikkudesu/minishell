<h1>Détail  d'étudiant : <?=$Etudiant["id"]?> </h1>
<hr/>
<ul>
<b> Code : <?=$Etudiant["CodeE"]?> </b><br/><br/>
<b> Nom : <?=$Etudiant["Nom"]?> </b><br/><br/>
<b> Prénom : <?= $Etudiant["Prenom"]?> </b><br/><br/>
<b> Filiere : <?=$Filiere["CodeF"]?> </b><br/><br/>
<b> Note : <?= $Etudiant["Note"]?> </b><br/><br/>
</ul>
<a href="index.php?action=Supprimer&id=<?=$Etudiant[0]?>">Supprimer</a>
<a href="index.php?action=edit&id=<?=$Etudiant[0]?>">Modifier</a>
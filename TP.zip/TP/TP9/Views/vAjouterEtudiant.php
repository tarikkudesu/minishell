<h1 >Ajouter un étudiant</h1>
<?php 
include ("form.php");


<h1>Liste des filières de la faculté</h1>
<hr/>
<ul>
<?php foreach($filiere as $f) { ?>
    <li><a href = "index.php?action=ListeEF&id=<?PHP echo $f["id"]?> "> <?php echo $f["NomF"]; ?> </a></li>
<?php } ?>
</ul>

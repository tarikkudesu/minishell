<h1>Autentification</h1>


<form name = "loginForm" action = "" method = "post" >
<pre>
<span class="Err"><?= $variables["erreur"]["User"] ?? "" ?> </span>
Login    <input name ="Login" type = "text" /> <span class="Err"><?= $variables["erreur"]["Login"] ?? "" ?> </span> (moi)

Password <input name ="PW" type = "password" /> <span class="Err"><?= $variables["erreur"]["PW"] ?? "" ?> </span>(douz)

        <input type ="checkbox" name ="ResterConnecte" /> Rester Connecté pour 15 jours 

         <input type = "submit" value = "Se Connecter" /> <input type = "reset" value ="Annuler" />
</pre>
</form>